import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.StandardSocketOptions;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.channels.DatagramChannel;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.UUID;

class tcpServer implements Runnable {
	HashMap<String, Object> map;
	
	//Store all connected clients.
	final HashMap<SelectionKey, ClientSession> 
	tcpSessionMap 										= new HashMap<SelectionKey, ClientSession>();
	
	//Store all client udp ports. 
	final HashMap<Integer, ClientSession>
	udpSessionMap 										= new HashMap<Integer, ClientSession>();
	
	//Store all clients registered on server.
	HashMap<String, ClientSession> client_map 			= new HashMap <String, ClientSession>();
	ArrayList<ClientSession> client_list 				= new ArrayList<ClientSession>();
	
	//Store all client list here.
	HashMap<String, ArrayList<ClientSession>> list_map 	= new HashMap <String, ArrayList<ClientSession>>();
	
	HashMap<String, Room> room_map						= new HashMap <String, Room>();
	HashMap<String, Namespace> namespace_map 			= new HashMap <String, Namespace>();
	
	String
	client_list_uuid									= UUID.randomUUID().toString(),
	version;
	
	boolean running;

	int fps, shutdown_alarm = 1, congestion_threshold, mtu, max_clients, tcpPort, udpPort;
	
	String ip, id;
    
    Selector selector;
    ServerSocketChannel tcpChannel;
    DatagramChannel udpChannel;
    
    SelectionKey tcpKey;
    SelectionKey udpKey;
    
    tcpServer(String id, String ip, int tcpPort, int udpPort, int max_clients, String version, int fps, int mtu) throws Throwable{
    	this.id 			= id;
    	this.ip 			= ip;
    	this.tcpPort 		= tcpPort;
    	this.udpPort 		= udpPort;
    	this.max_clients 	= max_clients;
    	this.version 		= version;
    	this.fps 			= fps;
    	this.mtu 			= mtu;
    	
    	selector 			= Selector.open();
    	
    	//Tcp channel
        tcpChannel 			= ServerSocketChannel.open();
        tcpChannel.configureBlocking(false);
        tcpKey 				= tcpChannel.register(selector, SelectionKey.OP_ACCEPT);
        tcpChannel.bind(new InetSocketAddress(ip, tcpPort), max_clients);
        tcpChannel.setOption(StandardSocketOptions.SO_REUSEADDR, true);
        
        //UdpChannel
        udpChannel 			= DatagramChannel.open();
        udpChannel.configureBlocking(false);
        udpKey 				= udpChannel.register(selector, SelectionKey.OP_READ);
        udpChannel.bind(new InetSocketAddress(ip, udpPort));
        udpChannel.setOption(StandardSocketOptions.SO_REUSEADDR, true);
        
        list_map.put(client_list_uuid, client_list);
        
        running = true;
    }
    
    @Override
    public void run(){
    	FileSystem.log("bnet server listening on ip: "+ip+" || tcp port: "+tcpPort+" || udp port: "+udpPort);
    	
    	while(shutdown_alarm > 0) {
    		if(!running) shutdown_alarm--;
    		
    		try {selector.selectNow();} catch (IOException e) {FileSystem.onError(e);}
        	
        	for (SelectionKey key : selector.selectedKeys()) {
        		try {
	        		if(!key.isValid()) continue;
	        		
	        		//Accept client connection
		        	if(key == tcpKey) {
		        		SocketChannel clientChannel = tcpChannel.accept();
		        		
		                if (clientChannel == null) continue;
		               
		                clientChannel.configureBlocking(false);
		                
		                SelectionKey clientKey 	= clientChannel.register(selector, SelectionKey.OP_READ);
		                
		                ClientSession client 	= new ClientSession(this, clientKey, clientChannel);
		                
		                tcpSessionMap.put(clientKey, client);
		        	}
		        	
		        	//Received data.
		        	if(key.isReadable()) {
		        		if(key == udpKey) {
			        		ByteBuffer udpBuffer = ByteBuffer.allocate(65536).order(ByteOrder.LITTLE_ENDIAN);
			        		
			        		InetSocketAddress address = ((InetSocketAddress) udpChannel.receive(udpBuffer));
			        		
			        		ClientSession client = udpSessionMap.get(address.getPort());
							
		        			if(client != null) client.onUdpRead(udpBuffer.flip());
		        			else {
		        				udpBuffer.flip().position(6);
		        				
		        				client = client_map.get(ClientSession.read_string(udpBuffer));
		        				
		        				if(client != null) {
		        					client.udpSocketAddress = address;
		        					
		        					udpSessionMap.put(address.getPort(), client);
		        					
		        					client.onUdpRead(udpBuffer.position(0));
		        				}
		        			}
		        			
		        			continue;
		        		}
		        		
		        		ClientSession client = tcpSessionMap.get(key);
		        		
	                    if (client != null) client.onTcpRead();
		        	}
	        	}catch(Throwable e) {FileSystem.onError(e);}
        	}
        	
        	selector.selectedKeys().clear();
    	}
    	
    	try {
    		selector.close();
    		
    		tcpChannel.close();
			
    		tcpChannel = null;
			
			udpChannel.close();
			
			udpChannel = null;
		} catch (IOException e) {FileSystem.onError(e);}
    	
    	synchronized(bnet.server_map) {bnet.server_map.remove(id);}
		
		synchronized(bnet.server_list) {bnet.server_list.remove(this);}
		
		FileSystem.log("bnet server terminated");
    }
    
    void onShutDown(int alarm){
    	FileSystem.log("bnet terminating server");
    	
		running 		= false;
    	shutdown_alarm 	= alarm * (fps*10);
	
		//BROADCAST A MESSAGE TO EVERY CLIENT THAT THE SERVER IS BEING DESTROYED.
		ByteBuffer write_buffer = ByteBuffer.allocate(6).order(ByteOrder.LITTLE_ENDIAN);
	
		write_buffer.put((byte) 0);
		write_buffer.put((byte) -2);
		write_buffer.putInt(alarm);
		
		ClientSession._bnet_network_send_broadcast_tcp("", client_list, write_buffer, null);
    }
}