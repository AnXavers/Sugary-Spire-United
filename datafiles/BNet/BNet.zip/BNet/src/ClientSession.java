import java.io.IOException;
import java.net.SocketAddress;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.channels.DatagramChannel;
import java.nio.channels.SelectionKey;
import java.nio.channels.SocketChannel;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.HashMap;

import org.eclipse.jetty.websocket.api.Session;

class ClientSession {
	//Server pointers
	ArrayList<ClientSession> server_client_list;
	HashMap<String, ClientSession> server_client_map;
	HashMap<String, ArrayList<ClientSession>> server_list_map;
	HashMap<String, Room> server_room_map;
	HashMap<String, Namespace> server_namespace_map;
	
	SocketAddress udpSocketAddress;
	    
    tcpServer tcpServer;
    webServer webServer;
	
	Session web_socket;
	DatagramChannel udpChannel;
	
	String 
	id = "", ip, name, client_list_uuid, version;
	
	Room room;
	
	boolean tamper_check, is_ws;
	
	//Global variables
	
	//Local variables
	SelectionKey selKey;
    SocketChannel tcpChannel;
    ByteBuffer write_buffer, stream_buffer 	= ByteBuffer.allocate(65536).order(LITTLE_ENDIAN).limit(1);
	
	static final ByteOrder LITTLE_ENDIAN 	= ByteOrder.LITTLE_ENDIAN;
	
	int
	mtu,
	tcpPort,
	udpPort,
	missing_bytes 							= 0,
	ping 									= 0;
	
	static ArrayList<Object[]> 
	database_task_list 						= Database.task_list,
	email_task_list 						= Email.task_list,
	file_system_task_list 					= FileSystem.task_list;
	
	HashMap<String, HashMap<String, Object>>
	udp_hashmap 							= new HashMap<String, HashMap<String, Object>>();
	
	ArrayList<HashMap<String, Object>> 
	udp_cache_list 							= new ArrayList<HashMap<String, Object>>();
    
	ClientSession(webServer server, Session session){
		webServer 				= server;
		
		ip 						= session.getRemoteAddress().getAddress().toString();
		tcpPort 				= session.getRemoteAddress().getPort();
		
		web_socket 				= session;
		
		//ServerConfiguration
        client_list_uuid		= webServer.client_list_uuid;
        version 				= webServer.version;
        
        //Server reference variables
        server_client_list 		= webServer.client_list;
        server_client_map 		= webServer.client_map;
        server_list_map 		= webServer.list_map;
        server_room_map			= webServer.room_map;
        server_namespace_map 	= webServer.namespace_map;
        
        is_ws 					= true;
	}
	
    ClientSession(tcpServer server, SelectionKey key, SocketChannel channel) throws Throwable {
    	tcpServer  				= server;
    	
    	ip 						= channel.socket().getInetAddress().toString();
    	tcpPort 				= channel.socket().getPort();
    	
        selKey 					= key;
        tcpChannel 				= (SocketChannel) channel.configureBlocking(false);
        
        //ServerConfiguration
        udpChannel 				= tcpServer.udpChannel;
        client_list_uuid		= tcpServer.client_list_uuid;
        version 				= tcpServer.version;
        
        mtu 					= tcpServer.mtu;
        
        //Server reference variables
        server_client_list 		= tcpServer.client_list;
        server_client_map 		= tcpServer.client_map;
        server_list_map 		= tcpServer.list_map;
        server_room_map			= tcpServer.room_map;
        server_namespace_map 	= tcpServer.namespace_map;
        
        is_ws 					= false;
    }
    
    void onWebRead(ByteBuffer source_buffer) {

    	ByteBuffer target_buffer;
    	
    	String header;
		
		target_buffer = source_buffer;
		
		//if(target_buffer.remaining() < 7) System.out.println("ws Packet less than 8");
		
		//if(target_buffer.remaining() < missing_bytes) System.out.println("ws not enough bytes in new packet");
		
		//If have previous data stored
		if(missing_bytes > 0) {
			target_buffer 	= stream_buffer;
			
			int size 		= 8 - target_buffer.limit();
			
			//If missing any header
			if(size > 0) {
				//Get remaining header bytes.
				target_buffer.limit(target_buffer.limit() + size).put(source_buffer.array(), 0, size);
				
				source_buffer.position(size);
				
				missing_bytes = (Short.toUnsignedInt(target_buffer.get(5)) + 1) + Short.toUnsignedInt(target_buffer.getShort(6));
			}
			
			//Increase limit to contain missing bytes.
			target_buffer.limit(target_buffer.limit() + missing_bytes).put(source_buffer.array(), source_buffer.position(), missing_bytes).flip();
			
			source_buffer.position(source_buffer.position() + missing_bytes);
			
			missing_bytes = 0;
		}
		
		while(target_buffer.remaining() > 7) {
			header = "";
			
			target_buffer.mark();
			
			for(int i = 0; i < 5; i++) header += (char) target_buffer.get();
			
			if(header.equals("BNet1")) {
				int 
				id_length 		= Short.toUnsignedInt(target_buffer.get()) + 1,
				
				buff_size 		= Short.toUnsignedInt(target_buffer.getShort()),
				
				target_size 	= id_length + buff_size;
				
				if(target_buffer.remaining() >= target_size) {
					String id 	= read_string(target_buffer);
					
					onProcess(ByteBuffer.allocate(buff_size).order(LITTLE_ENDIAN).put(target_buffer.array(), target_buffer.position(), buff_size).flip(), id, true);
					
					target_buffer.position(target_buffer.position() + buff_size);
					
					if(target_buffer.equals(stream_buffer)) target_buffer = source_buffer;
					
					int remaining = target_buffer.remaining();
					
					//Not enough bytes to complete next header.
					if(remaining > 0 && remaining < 8) {
						stream_buffer.clear().limit(remaining).put(target_buffer);
						
						missing_bytes = 8 - remaining;
						
						break;
					}
				}else {
					int prev_remain = target_buffer.remaining();
					
					target_buffer.reset();
					
					int remaining = target_buffer.remaining();
					
					stream_buffer.clear().limit(remaining).put(target_buffer);
					
					missing_bytes = target_size - prev_remain;
					
					break;
				}
			}else {
				System.out.println("header: "+id+" :: "+header);
			}
		}
    }
 
    void onTcpRead() {
    	int input 		= -1;
		
    	ByteBuffer 
    	source_buffer 	= ByteBuffer.allocate(65536).order(LITTLE_ENDIAN), 
    	target_buffer;
    	
    	try {input = tcpChannel.read(source_buffer);}catch (IOException e) {onError(e); return;}
    	
    	if(input == -1) onDisconnect();
    	
    	if(input < 1) return;
    	
    	source_buffer.flip();
    	
    	String header;
		
		target_buffer = source_buffer;
		
		if(target_buffer.remaining() < 7) {
			//System.out.println("tcp Packet less than 8");
		}
		
		if(target_buffer.remaining() < missing_bytes){
			//System.out.println("not enough bytes in new packet");
		}
		
		//If have previous data stored
		if(missing_bytes > 0) {
			target_buffer 	= stream_buffer;
			
			int size 		= 8 - target_buffer.limit();
			
			//If missing any header
			if(size > 0) {
				//Get remaining header bytes.
				target_buffer.limit(target_buffer.limit() + size).put(source_buffer.array(), 0, size);
				
				source_buffer.position(size);
				
				missing_bytes = (Short.toUnsignedInt(target_buffer.get(5)) + 1) + Short.toUnsignedInt(target_buffer.getShort(6));
			}
			
			//Increase limit to contain missing bytes.
			target_buffer.limit(target_buffer.limit() + missing_bytes).put(source_buffer.array(), source_buffer.position(), missing_bytes).flip();
			
			source_buffer.position(source_buffer.position() + missing_bytes);
			
			missing_bytes = 0;
		}
		
		while(target_buffer.remaining() > 7) {
			header = "";
			
			target_buffer.mark();
			
			for(int i = 0; i < 5; i++) header += (char) target_buffer.get();
			
			if(header.equals("BNet0")) {
				int 
				id_length 		= Short.toUnsignedInt(target_buffer.get()) + 1,
				
				buff_size 		= Short.toUnsignedInt(target_buffer.getShort()),
				
				target_size 	= id_length + buff_size;
				
				if(target_buffer.remaining() >= target_size) {
					String id 	= read_string(target_buffer);
					
					onProcess(ByteBuffer.allocate(buff_size).order(LITTLE_ENDIAN).put(target_buffer.array(), target_buffer.position(), buff_size).flip(), id, true);
					
					target_buffer.position(target_buffer.position() + buff_size);
					
					if(target_buffer.equals(stream_buffer)) target_buffer = source_buffer;
					
					int remaining = target_buffer.remaining();
					
					//Not enough bytes to complete next header.
					if(remaining > 0 && remaining < 8) {
						stream_buffer.clear().limit(remaining).put(target_buffer);
						
						missing_bytes = 8 - remaining;
						
						break;
					}
				}else {
					int prev_remain = target_buffer.remaining();
					
					target_buffer.reset();
					
					int remaining = target_buffer.remaining();
					
					stream_buffer.clear().limit(remaining).put(target_buffer);
					
					missing_bytes = target_size - prev_remain;
					
					break;
				}
			}else {
				System.out.println("header: "+id+" :: "+header);
			}
		}
    }
    
    @SuppressWarnings("unchecked")
	void onUdpRead(ByteBuffer source_buffer) {
    	//Shrink packet size if necessary.
		int 
		offset 		= 0,
		size 		= source_buffer.limit();
		
		boolean debug = false;
		
		while (true) {
			String header = "";
			
			for(int i = 0; i < 5; i++) header += (char) source_buffer.get();
			
			boolean check = false;
			
			if(header.equals("BNet0")) {
				
				// Check tag of received buffer.
				short id_length 		= (short) Byte.toUnsignedInt(source_buffer.get());
				String 
				client_id 				= read_string(source_buffer),
				tag 					= read_string(source_buffer);
				
				// Read received buffer headers.
				int 
				index 					= Short.toUnsignedInt(source_buffer.getShort()),
				segment_size 			= Short.toUnsignedInt(source_buffer.getShort());
				long total_size 		= Integer.toUnsignedLong(source_buffer.getInt());
				
				// Get source buffer offset.
				offset 					= source_buffer.position();
				
				//Get current read buffer.
				HashMap<String, Object> current_buffer 	= udp_hashmap.get(tag);

				//If buffer doesnt exists cache it.
				if(current_buffer == null) {
					current_buffer = new HashMap<String, Object>();
					
					//Buffer tag.
					current_buffer.put("tag",  tag);
					
					//Buffer size.
					current_buffer.put("size",  0);
					
					//Buffer list.
					current_buffer.put("list",  new ArrayList<ByteBuffer>());
					
					//Add buffer to cache list.
					udp_hashmap.put(tag,  current_buffer);
					
					udp_cache_list.add(current_buffer);
				}
				
				//Search for duplicate ids if there's ids present. if found omit id.
				if(current_buffer.get(String.valueOf(index)) != null) {
					check = true;
					
					if(debug) System.out.println(tag+": index ["+index+"] omitted");
					break;
				}
				
				if (!check) {
					// Create a temporary buffer.
					ByteBuffer temp_buffer = ByteBuffer.allocate(segment_size).order(LITTLE_ENDIAN);
					//System.out.println("decode: "+size+" :: "+source_buffer.remaining()+" :: "+offset+" :: "+segment_size+" :: "+(source_buffer.limit() - source_buffer.position()));
					temp_buffer.put(source_buffer.array(), offset, Math.min(segment_size, source_buffer.remaining()));
					
					// Increase stored buffer size for checking.
					current_buffer.put("size", ((Integer) current_buffer.get("size")) + segment_size);
					
					// Add temporary buffer to stored buffer array.
					current_buffer.put(String.valueOf(index),  temp_buffer);
					
					((ArrayList<ByteBuffer>) current_buffer.get("list")).add(temp_buffer);
					
					if(debug) System.out.println(tag+": "+index+" "+total_size+" "+segment_size);
					
					// Check if all data is received.
					if ((int) current_buffer.get("size") == total_size) {
						
						temp_buffer = ByteBuffer.allocate((int) total_size).order(LITTLE_ENDIAN);
						
						int map_size = current_buffer.size();
						
						ByteBuffer copy_buffer;
						
						for(int i = 0; i < map_size - 3; i++) {
							copy_buffer = (ByteBuffer) current_buffer.get(String.valueOf(i));
							
							temp_buffer.put(copy_buffer.array(), 0, copy_buffer.limit());
							
							copy_buffer = null;
						}
						
						//Check to see if tamper check is disabled if not, check to see if packet corrupted.
						if(!tamper_check|| buffer_sha1(temp_buffer, 0, (int) total_size).equals(tag)){
							
							//If all seems fine process packet.
							onProcess(temp_buffer.flip(), client_id, false);
							
							if(debug) System.out.println("Buffer decoded successfully.\n["+(udp_cache_list.size()-1)+"] incomplete buffer(s).");
						}else {
							//Delete buffer due to tampering.
							if(debug) System.out.println("Buffer: "+udp_cache_list.size()+" deleted due to corruption.");
							temp_buffer = null;
						}
						
						//Remove current buffer array from cache list.
						udp_cache_list.remove(current_buffer);
						
						current_buffer.put("list",  null);
						
						current_buffer = null;
						
						udp_hashmap.remove(tag);
					}
				}
				
				// Set buffer new offset.
				source_buffer.position(Math.min(segment_size + offset, source_buffer.remaining()));
				
				//If potential new packet size greater than buffer stop looping.
				if(offset + segment_size + 56 + id_length > size) break;
			} else {
				// Buffer isn't bnet encoded. Reset buffer seek position.
				//source_buffer.position(offset);
				switch(header){
					case "BNet0":
						System.out.println("BNet buffer decode failed. Recieved packet from websocket.");
					break;
					default:
						System.out.println("BNet buffer decode failed. Buffer isnt bnet encoded: { "+header+" }");
					break;
				}
				
				break;
			}
		}
    }
    
    void onProcess(ByteBuffer buffer, String client_id, boolean is_tcp) {
		switch ((byte) buffer.get()) {
			case -128://SERVER REGISTRY
				String id_ 	= read_string(buffer);
				
				//Ensure the client isnt already connected.
				if(server_client_map.get(id_) != null) {
					sendError("000");
					
					if(bnet.debug.get()) FileSystem.log(id, "{ "+id_+" } ALREADY CONNECTED.");
					
					if(!is_ws) {
						tcpServer.udpSessionMap.remove(udpPort);
						
						tcpServer.tcpSessionMap.remove(selKey);
				    	
				    	try {
				    		if(selKey != null) selKey.cancel();
				    		
				    		if(tcpChannel == null) break;
				    		
				    		tcpChannel.close();
				    	}catch(Throwable t) {}
					}else webServer.sessionMap.remove(web_socket);
					
					break;
				}
				
				id 			= id_;
				name 		= read_string(buffer);
				
				if(!is_ws) {
					udpPort = Short.toUnsignedInt(buffer.getShort());
					
					tcpServer.udpSessionMap.put(udpPort, this);
				}
				
				//Notify all clients that i joined.
				write_buffer = ByteBuffer.allocate(2).order(LITTLE_ENDIAN);
				
				write_buffer.put((byte) 0);
				write_buffer.put((byte) 3);
				
				write_buffer = serialize(write_buffer, this);
				
				write_buffer = buffer_resize(write_buffer, write_buffer.position());
				
				_bnet_network_send_broadcast_tcp(id_, server_client_list, write_buffer, this);
				
				server_client_map.put(id_, this);
				
				server_client_list.add(this);
				
				write_buffer = ByteBuffer.allocate(3 + client_list_uuid.length()).order(LITTLE_ENDIAN);
				
				write_buffer.put((byte) 0);
				write_buffer.put((byte) 0);
				write_buffer.put((client_list_uuid+"\0").getBytes());
				
				write_buffer = list_serialize(write_buffer, server_client_list);
				
				_bnet_network_send_raw(this, write_buffer, write_buffer.position());
				
				if(bnet.debug.get()) FileSystem.log(id, "{ "+id+" } JOINED THE SERVER [ "+server_client_list.size()+" ] PLAYERS");
			break;
			case -7:// BROADCAST BUFFER
				ArrayList<ClientSession> lb = server_list_map.get(read_string(buffer));
				
				if(lb != null) {
					if(is_tcp) _bnet_network_send_broadcast_tcp(id, lb, buffer, null);
					else _bnet_network_send_broadcast_udp(id, lb, buffer, null);
					
					if(bnet.debug.get()) FileSystem.log(id, "BROADCASTED A BUFFER");
				}else {
					sendError("007");
					
					if(bnet.debug.get()) FileSystem.log(id, " FAILED TO BROADCAST A BUFFER. INVALID LIST ID");
				}
			break;
			case -6://BUFFER SEND
				ClientSession be = server_client_map.get(read_string(buffer));
				
				if(be != null) {
					if(is_tcp) _bnet_network_send_raw(be, buffer, buffer.capacity());
					else _bnet_network_send_udp_raw(be, buffer);
					
					if(bnet.debug.get()) FileSystem.log(id, "SENT A PACKET TO A CLIENT");
				}else {
					sendError("006");
					
					if(bnet.debug.get()) FileSystem.log(id, "FAILED TO SEND A PACKET TO A CLIENT FAILED. INVALID CLIENT ID.");
				}
			break;
			case -5://VERSION CHECK
				write_buffer = ByteBuffer.allocate(2 + version.length()).order(LITTLE_ENDIAN);
				
				write_buffer.put((byte) -5);
				write_buffer.put((version +"\0").getBytes());
				
				_bnet_network_send_raw(this, write_buffer, write_buffer.position());
				
				if(bnet.debug.get()) FileSystem.log(id, "REQUESTED VERSION");
			break;
			case -4:// BROADCAST CUSTOM EVENT
				ArrayList<ClientSession> le = server_list_map.get(read_string(buffer));
				
				if(le != null) {
					if(is_tcp) _bnet_network_send_broadcast_tcp(id, le, buffer, null);
					else _bnet_network_send_broadcast_udp(id, le, buffer, null);
					
					if(bnet.debug.get()) FileSystem.log(id, "BROADCASTED AN EVENT");
				}else {
					sendError("004");
					
					if(bnet.debug.get()) FileSystem.log(id, " FAILED TO BROADCAST AN EVENT. INVALID LIST ID");
				}
			break;
			case -3://SEND TO TARGETED CLIENT
				ClientSession ce = server_client_map.get(read_string(buffer));
					
				if(ce != null) {
					if(is_tcp) _bnet_network_send_raw(ce, buffer, buffer.capacity());
					else _bnet_network_send_udp_raw(ce, buffer);
					
					if(bnet.debug.get()) FileSystem.log(id, "SENT AN EVENT TO A CLIENT");
				}else {
					sendError("003");
					
					if(bnet.debug.get()) FileSystem.log(id, "FAILED TO SEND AN EVENT TO A CLIENT. INVALID CLIENT ID");
				}
			break;
			case -1://PING
				ping = Byte.toUnsignedInt((byte) buffer.getShort());
				
				if(is_tcp) _bnet_network_send_raw(this, buffer, buffer.capacity());
				else _bnet_network_send_udp_raw(this, buffer);
				
				//System.out.println("["+system_timestamp+ "] Pinging: "+id);
			break;
			case 0:
				switch(buffer.get()) {
					case 1:
						if(bnet.debug.get()) FileSystem.log(id, "REQUESTED TO DISCONNECT FROM SERVER");
						
						onDisconnect(); 
					break;
				}
			break;
			case 1://CHAT
				ArrayList<ClientSession> message_client_list;
				
				switch (buffer.get()) {
					case 0:
						String 
						message = read_string(buffer),
						list_id = read_string(buffer);
						
						if(!list_id.equals("")) {
							message_client_list = null;
							
							message_client_list = server_list_map.get(list_id);
							
							if(message_client_list != null) {
								write_buffer = ByteBuffer.allocate(2).order(LITTLE_ENDIAN);
								
								write_buffer.put((byte) 1);
								write_buffer.put((byte) 0);
								
								write_buffer = serialize(write_buffer, this);
								
								write_buffer = buffer_put_bytes(write_buffer, (list_id + "\0").getBytes());
								write_buffer = buffer_put_bytes(write_buffer, (message + "\0").getBytes());
								
								write_buffer = buffer_resize(write_buffer, write_buffer.position());
								
								_bnet_network_send_broadcast_tcp(id, message_client_list, write_buffer, null);
								
								if(bnet.debug.get()) FileSystem.log(id, "SENT A MESSAGE TO EVERYONE");
							}else{
								sendError("100");
								
								if(bnet.debug.get()) FileSystem.log(id, "FAILED TO SEND A MESSAGE TO EVERYONE INVALID LIST");
							}
						}else {
							ClientSession c = server_client_map.get(read_string(buffer));
							
							if(c != null) {
								write_buffer = ByteBuffer.allocate(3).order(LITTLE_ENDIAN);
								
								write_buffer.put((byte) 1);
								write_buffer.put((byte) 0);
								
								write_buffer = serialize(write_buffer, this);
								
								write_buffer = buffer_put_bytes(write_buffer, (list_id + "\0").getBytes());
								write_buffer = buffer_put_bytes(write_buffer, (message + "\0").getBytes());
								
								//Send back to client.
								_bnet_network_send_raw(this, write_buffer, write_buffer.position());
								
								//Send to targeted client.
								_bnet_network_send_raw(c, write_buffer, write_buffer.position());
								
								if(bnet.debug.get()) FileSystem.log(id, "SENT A MESSAGE TO A CLIENT");
							}else{
								sendError("101");
								
								if(bnet.debug.get()) FileSystem.log(id, "FAILED TO SEND A MESSAGE TO A CLIENT INVALID ID");
							}
						}
					break;
					case 1:// VOIP
						String list = read_string(buffer);
						
						message_client_list = server_list_map.get(list);
						
						if (message_client_list != null) {
							write_buffer = ByteBuffer.allocate(9 + list.length()).order(LITTLE_ENDIAN);
							
							write_buffer.put((byte) 1);
							write_buffer.put((byte) 1);
							write_buffer.put((list+"\0").getBytes());
							write_buffer.putShort(buffer.getShort());//sample rate
							write_buffer.putShort(buffer.getShort());//duration
							
							int size = Short.toUnsignedInt(buffer.getShort());
							
							write_buffer.putShort((short) size);
							
							write_buffer = serialize(write_buffer, this);
							
							write_buffer = buffer_put_bytes(write_buffer, buffer.array(), buffer.position(), size);
							
							write_buffer = buffer_resize(write_buffer, write_buffer.position());
							
							if(is_tcp) _bnet_network_send_broadcast_tcp(id, message_client_list, write_buffer, this);
							else _bnet_network_send_broadcast_udp(id, message_client_list, write_buffer, this);
							
							if(bnet.debug.get()) FileSystem.log(id, "BROADCASTED A VOIP");
						}else {
							sendError("102");
							
							if(bnet.debug.get()) FileSystem.log(id, "FAILED TO SEND A VOIP TO A CLIENT INVALID LIST ID");
						}
					break;
				}
			break;
			case 2://ROOM
				byte rheader = (byte) buffer.get();
				
				String room_goto = read_string(buffer);
				
				switch(rheader) {
					case 0://GOTO
						Room goto_room;
						
						//Remove myself from previous room if in one.
						if(room != null){
							
							if(room_goto.equals(room.id)) {
								sendError("200");
								
								if(bnet.debug.get()) FileSystem.log(id, "FAILED TO SWAP ROOM, CANT SWITCH INTO SAME ROOM");
								
								break;
							}
							
							room.client_list.remove(this);
							
							room.client_map.remove(id);
						
							//If client list empty,
							if(room.client_list.isEmpty()) {
								//and it set to destroy clean it up.
								if(room.destroy) {
									room.cleanup();
									
									if(bnet.debug.get()) FileSystem.log(id, "ROOM AUTO DESTROYED DUE TO BEING EMPTY");
								}
							}else {
								//If im host pick another based off lower ping.
								if(room.host == this) {
									ClientSession 
									client_,
									host = room.client_list.get(0);
									
									int
									ping = host.ping,
									size = room.client_list.size();
									
									for(int i = 1; i < size; i++) {
										client_ = room.client_list.get(i);
										
										if(client_.ping < ping) host = client_;
									}
									
									room.host = host;
								}
								
								//Notfiy all clients within my room that i left.
								write_buffer = ByteBuffer.allocate(2).order(LITTLE_ENDIAN);
								
								write_buffer.put((byte) 2);
								write_buffer.put((byte) 2);
								
								write_buffer = serialize(write_buffer, this);
								
								write_buffer = buffer_put_bytes(write_buffer, (room.host.id + "\0").getBytes());
								
								write_buffer = buffer_resize(write_buffer, write_buffer.position());
								
								_bnet_network_send_broadcast_tcp(id, room.client_list, write_buffer, null);
							}
							
							//Check to see if client wishes to leave room.
							if(room_goto.equals("-1")) {
								room = null;
								
								write_buffer = ByteBuffer.allocate(2).order(LITTLE_ENDIAN);
								
								write_buffer.put((byte) 2);
								write_buffer.put((byte) -1);
								
								_bnet_network_send_raw(this, write_buffer, 2);
								
								if(bnet.debug.get()) FileSystem.log(id, "LEFTED ROOM");
								
								break;
							}
						}else if(room_goto.equals("-1")) {
							sendError("201");
							
							if(bnet.debug.get()) FileSystem.log(id, "FAILED TO LEAVE ROOM, ALREADY LEFT");
							
							break;
						}
						
						//Search to see if room exists.
						goto_room = server_room_map.get(room_goto);
						
						//If it exists.
						if(goto_room != null) {
							write_buffer = ByteBuffer.allocate(2).order(LITTLE_ENDIAN);
							
							write_buffer.put((byte) 2);
							write_buffer.put((byte) 1);
							
							write_buffer = serialize(write_buffer, this);
							
							write_buffer = buffer_resize(write_buffer, write_buffer.position());
							
							_bnet_network_send_broadcast_tcp(id, goto_room.client_list, write_buffer, this);
						}else{
							//Else Create it.
							if(is_ws) goto_room = new Room(webServer);
							else goto_room 		= new Room(tcpServer);
							goto_room.host 		= this;
							goto_room.id 		= room_goto;
							goto_room.destroy 	= buffer.get() > 0? true: false;
							
							//Add room to server room cache.
							server_room_map.put(room_goto, goto_room);
							
							//Add room participant list to list hashMap
							server_list_map.put(room_goto, goto_room.client_list);
						}
						
						//Add myself to room.
						goto_room.client_list.add(this);
						
						goto_room.client_map.put(id, this);
						
						//Update client's room.
						room = goto_room;
						
						write_buffer = ByteBuffer.allocate(8 + room_goto.length() + goto_room.host.id.length()).order(LITTLE_ENDIAN);
						
						write_buffer.put((byte) 2);
						write_buffer.put((byte) 0);
						write_buffer.put((room_goto + "\0").getBytes());
						write_buffer.put((goto_room.host.id + "\0").getBytes());
						
						write_buffer = list_serialize(write_buffer, goto_room.client_list);
						
						write_buffer = instance_list_serialize(write_buffer, goto_room.instance_list);
						
						_bnet_network_send_raw(this, write_buffer, write_buffer.position());
						
						if(bnet.debug.get()) FileSystem.log(id, "SWAPPED ROOM");
					break;
					case 3://ROOM UPDATE
						//Verify that a room exists.
						Room room = server_room_map.get(room_goto);
						
						if(room != null) {
							String cid 	= read_string(buffer);
							
							byte des 	= buffer.get();
							
							ClientSession host = room.host;
							
							if(!cid.equals("")) {
								//Check to see if client exists.
								ClientSession c = room.client_map.get(cid);
								
								//If client exists.
								if(c != null) {
									room.host 	= c;
									
									host 		= c;
									
									if(bnet.debug.get()) FileSystem.log(id, "PASSED LEAD");
								}else {
									sendError("202");
									
									if(bnet.debug.get()) FileSystem.log(id, "FAILED TO PASS LEAD INVALID CLIENT ID");
								}
							}
							
							if(des != -1) {
								boolean destroy = (des < 1? false: true);
								
								if(room.destroy != destroy) {
									room.destroy = destroy;
									
									//Update destroy within buffer.
									des = (destroy? des = 1: 0);
									
									if(bnet.debug.get()) FileSystem.log(id, "UPDATED A ROOM DESTROY PARAMETER");
									
									//Check to see if room empty, and set to destroy. if so destroy it.
									if(room.destroy && room.client_list.isEmpty()) {
										room.cleanup();
										
										if(bnet.debug.get()) FileSystem.log(id, "ROOM AUTO DESTROYED DUE TO BEING EMPTY");
									}
								}
							}
							
							write_buffer = ByteBuffer.allocate(5 + room_goto.length()).order(LITTLE_ENDIAN);
							
							write_buffer.put((byte) 2);
							write_buffer.put((byte) 3);
							
							write_buffer = serialize(write_buffer, host);
							
							write_buffer.put((room_goto + "\0").getBytes());
							
							write_buffer.put((byte) des);
							
							write_buffer = buffer_resize(write_buffer, write_buffer.position());
							
							_bnet_network_send_broadcast_tcp(id, room.client_list, write_buffer, this);
							
							if(bnet.debug.get()) FileSystem.log(id, "UPDATED ROOM");
						}else {
							sendError("203");
							
							if(bnet.debug.get()) FileSystem.log(id, "FAILED TO UPDATE A ROOM INVALID ID");
						}
					break;
				}
			break;
			case 3://INSTANCES
				Instance instance;
				String instance_id;
				
				byte header 	= (byte) buffer.get();
				
				String room_id 	= read_string(buffer);
				
				Room room 		= server_room_map.get(room_id);
				
				switch(header) {
					case 0://CREATE
						if(room != null) {
							boolean self = buffer.get() > 0? true: false;
							
							//If client requests to cache the instance.
							if(buffer.get() > 0) {
								//Store it within hashmap.
								instance = instance_deserialize(buffer);
								
								if(room.instance_map.get(instance.id) == null) {
									room.instance_map.put(instance.id, instance);
									
									room.instance_list.add(instance);
								}else {
									sendError("300");
									
									if(bnet.debug.get()) FileSystem.log(id, "FAILED TO CACHE AN INSTANCE. INSTANCE ALREADY EXISTS.");
								
									break;
								}
							}
							
							_bnet_network_send_broadcast_tcp(id, room.client_list, buffer, self? null: this);
							
							if(bnet.debug.get()) FileSystem.log(id, "CREATED AN INSTANCE");
						}else{
							sendError("301");
							
							if(bnet.debug.get()) FileSystem.log(id, "FAILED TO CREATE AN INSTANCE. NOT WITHIN A ROOM");
						}
					break;
					case 1://DESTROY
						if(room != null) {
							instance_id = read_string(buffer);
							
							instance 	= room.instance_map.get(instance_id);
							
							if(instance != null) {
								room.instance_list.remove(instance);
								
								room.instance_map.remove(instance_id);
								
								instance = null;
								
								if(bnet.debug.get()) FileSystem.log(id, "DESTROYED AN INSTANCE");
							}else{
								sendError("302");
								
								if(bnet.debug.get()) FileSystem.log(id, "FAILED TO DESTROY AN INSTANCE. INAVLID ID OR ITS NOT CACHED");
							}
							
							_bnet_network_send_broadcast_tcp(id, room.client_list, buffer, null);
						}else{
							sendError("303");
							
							if(bnet.debug.get()) FileSystem.log(id, "FAILED TO DESTROY AN INSTANCE. NOT WITHIN A ROOM");
						}
					break;
					case 2: case 3://UPDATE
						if(room != null) {
							if(header == 2 || room.host == this) {
								instance = room.instance_map.get(read_string(buffer));
								
								if(instance != null) {
									//Can perform collision checks here.
									instance.object_index 	= read_string(buffer);
									instance.sprite_index 	= read_string(buffer);
									instance.x 				= buffer.getInt();
									instance.y 				= buffer.getInt();
									//instance.setDepth(buffer.getInt());
									
									//buffer.position(0);
									
									if(bnet.debug.get()) FileSystem.log(id, "UPDATED AN INSTANCE");
								}else {
									sendError("304");
									
									if(bnet.debug.get()) FileSystem.log(id, "FAILED TO UPDATE AN INSTANCE. INVALID ID.");
								}
								
								if(is_tcp) _bnet_network_send_broadcast_tcp(id, room.client_list, buffer, null);
								else _bnet_network_send_broadcast_udp(id, room.client_list, buffer, null);
							}else {
								sendError("305");
								
								if(bnet.debug.get()) FileSystem.log(id, "FAILED TO UPDATE AN NPC NOT ROOM LEAD.");
							}
						}else{
							sendError("306");
							
							if(bnet.debug.get()) FileSystem.log(id, "FAILED TO UPDATE AN INSTANCE. NOT WITHIN A ROOM.");
						}
					break;
					case 4://LOCKSTEP
						if(room != null) {
							if(is_tcp) _bnet_network_send_broadcast_tcp(id, room.client_list, buffer, this);
							else _bnet_network_send_broadcast_udp(id, room.client_list, buffer, this);
						}else{
							sendError("307");
							
							if(bnet.debug.get()) FileSystem.log(id, "FAILED TO SEND LOCKSTEP FRAME. NOT WITHIN A ROOM.");
						}
					break;
				}
			break;
			case 4:// FILE
				file_system_task_list.add(new Object[] {this, buffer});
			break;
			case 5://NAMESPACE
				switch(buffer.get()) {
					case 0://CREATE
						String name = read_string(buffer);
						
						Namespace n = server_namespace_map.get(name);
						
						if(n == null) {
							if(is_ws) n = new Namespace(webServer);
							else 	n 	= new Namespace(tcpServer);
							n.name 		= name;
							
							server_namespace_map.put(name, n);
							
							server_list_map.put(name, n.client_list);
							
							write_buffer = ByteBuffer.allocate(3 + n.name.length()).order(LITTLE_ENDIAN);
							
							write_buffer.put((byte) 5);
							write_buffer.put((byte) 0);
							write_buffer.put((n.name+"\0").getBytes());
					        
							_bnet_network_send_raw(this, write_buffer, write_buffer.position());
							
							if(bnet.debug.get()) FileSystem.log(id, "CREATED A NAMESPACE.");
						}else {
							sendError("500");
							
							if(bnet.debug.get()) FileSystem.log(id, "FAILED TO CREATE NAMESPACE. ALREADY EXISTS");
						}
					break;
					case 1://ADD
						Namespace ns = server_namespace_map.get(read_string(buffer));
						
						if(ns != null) {
							ClientSession c = null;
							
							c = server_client_map.get(read_string(buffer));
							
							if(c != null) {
								if(ns.client_map.get(c.id) == null) {
									ns.client_map.put(c.id, c);
									
									ns.client_list.add(c);
									
									write_buffer = ByteBuffer.allocate(5 + ns.name.length()).order(LITTLE_ENDIAN);
									
									write_buffer.put((byte) 5);
									write_buffer.put((byte) 1);
									write_buffer.put((ns.name+"\0").getBytes());
									
									write_buffer = list_serialize(write_buffer, ns.client_list);
									
									write_buffer = buffer_resize(write_buffer, write_buffer.position());
									
									_bnet_network_send_broadcast_tcp(id, ns.client_list, write_buffer, null);
									
									if(bnet.debug.get()) FileSystem.log(id, "ADDED A CLIENT TO A NAMESPACE.");
								}else {
									sendError("501");
									
									if(bnet.debug.get()) FileSystem.log(id, "FAILED TO ADD A CLIENT TO NAMESPACE. CLIENT ALREADY WITHIN IT");
								}
							}else {
								sendError("502");
								
								if(bnet.debug.get()) FileSystem.log(id, "FAILED TO ADD A CLIENT TO NAMESPACE. CLIENT DOESNT EXISTS");
							}
						}else {
							sendError("503");
							
							if(bnet.debug.get()) FileSystem.log(id, "FAILED TO ADD A CLIENT TO NAMESPACE. NAMESPACE DOESNT EXISTS");
						}
					break;
					case 2://DELETE
						Namespace dns = server_namespace_map.get(read_string(buffer));
						
						if(dns != null) {
							ClientSession c = dns.client_map.get(read_string(buffer));
							
							if(c != null) {
								write_buffer = ByteBuffer.allocate(5 + dns.name.length()).order(LITTLE_ENDIAN);
								
								write_buffer.put((byte) 5);
								write_buffer.put((byte) 1);
								write_buffer.put((dns.name+"\0").getBytes());
								
								write_buffer = list_serialize(write_buffer, dns.client_list);
								
								write_buffer = buffer_resize(write_buffer, write_buffer.position());
								
								_bnet_network_send_broadcast_tcp(id, dns.client_list, write_buffer, null);
									
								dns.client_list.remove(c);
								
								dns.client_map.remove(c.id);
								
								if(bnet.debug.get()) FileSystem.log(id, "DELETED A CLIENT FROM A NAMESPACE.");
							}else {
								sendError("504");
								
								if(bnet.debug.get()) FileSystem.log(id, "FAILED TO DELETE A CLIENT FROM NAMESPACE. CLIENT DOESNT EXISTS");
							}
						}else {
							sendError("505");
							
							if(bnet.debug.get()) FileSystem.log(id, "FAILED TO DELETE A CLIENT FROM NAMESPACE. NAMESPACE DOESNT EXISTS");
						}
					break;
					case 3://DESTROY
						String nsn 		= read_string(buffer);
						Namespace ddns 	= server_namespace_map.get(nsn);
							
						if(ddns != null) {
							write_buffer = ByteBuffer.allocate(3 + ddns.name.length()).order(LITTLE_ENDIAN);
							
							write_buffer.put((byte) 5);
							write_buffer.put((byte) 2);
							write_buffer.put((ddns.name+"\0").getBytes());
							
							write_buffer = buffer_resize(write_buffer, write_buffer.position());
							
							_bnet_network_send_broadcast_tcp(id, ddns.client_list, write_buffer, null);
							
							ddns.cleanup();
							ddns = null;
							
							if(bnet.debug.get()) FileSystem.log(id, "DESTROYED A NAMESPACE");
						}else {
							sendError("506");
							
							if(bnet.debug.get()) FileSystem.log(id, "FAILED TO DESTROY NAMESPACE. NAMESPACE DOESNT EXISTS");
						}
					break;
				}
			break;
			case 6://MONGODB
				database_task_list.add(new Object[] {this, buffer});
			break;
			case 7:// EMAIL
				email_task_list.add(new Object[] {this, buffer});
			break;
			case 8:// UDPHP
				String id = read_string(buffer);
				
				ClientSession client = server_client_map.get(read_string(buffer));
				
				if (client != null) {
					write_buffer = ByteBuffer.allocate(11 + client.name.length() + client.ip.toString().length() + client.id.length()).order(LITTLE_ENDIAN);
					
					write_buffer.put((byte) 254);
					write_buffer.put((byte) 0);
					write_buffer.put((client.id + "\0").getBytes());
					write_buffer.put((client.name +"\0").getBytes());
					write_buffer.put((client.ip.toString() +"\0").getBytes());
					write_buffer.putShort((short) client.udpPort);
					//write_buffer.putShort((short) udphp_timer);
					write_buffer.putShort((short) client.ping);
					
					_bnet_network_send_raw(this, write_buffer, write_buffer.position());

					write_buffer = ByteBuffer.allocate(11 + name.length() + ip.toString().length()).order(LITTLE_ENDIAN);
					
					write_buffer.put((byte) 254);
					write_buffer.put((byte) 0);
					write_buffer.put((id + "\0").getBytes());
					write_buffer.put((name +"\0").getBytes());
					write_buffer.put((ip.toString() +"\0").getBytes());
					write_buffer.putShort((short) udpPort);
					//write_buffer.putShort((short) udphp_timer);
					write_buffer.putShort((short) ping);
					
					_bnet_network_send_raw(client, write_buffer, write_buffer.position());
					
					if(bnet.debug.get()) FileSystem.log(id, "UDPHP START REQUEST SENT");
					
					break;
				}else {
					sendError("800");
					
					if(bnet.debug.get()) FileSystem.log(id, "FAILED TO REQUEST UDPHP, CLIENT DOESNT EXISTS");
				}
			break;
		}
		
		buffer = null;
    }
    
    void onDisconnect(){
		if(room != null) {
			room.client_map.remove(id);
		
			room.client_list.remove(this);
		
			//If client list empty, destroy the room if room set to auto destroy.
			if(room.destroy && room.client_list.isEmpty()) {
				room.cleanup();
				
				if(bnet.debug.get()) FileSystem.log(id, "ROOM AUTO DESTROYED DUE TO BEING EMPTY");
			}else {
				//Notify all clients within my room that i left.
				if(room.host == this) room.host = room.client_list.get(0);
				
				ByteBuffer write_buffer = ByteBuffer.allocate(2).order(LITTLE_ENDIAN);
				
				write_buffer.put((byte) 2);
				write_buffer.put((byte) 2);
				
				write_buffer = serialize(write_buffer, this);
				
				write_buffer = buffer_put_bytes(write_buffer, (room.host.id + "\0").getBytes());
				
				write_buffer = buffer_resize(write_buffer, write_buffer.position());
				
				_bnet_network_send_broadcast_tcp(id, room.client_list, write_buffer, this);
				
				if(bnet.debug.get()) FileSystem.log(id, "NOTIFIED ALL CLIENTS WITHIN ROOM THAT I DISCONNECTED");
			}
		}
		
		ByteBuffer write_buffer = ByteBuffer.allocate(2).order(LITTLE_ENDIAN);
		
		write_buffer.put((byte) 0);
		write_buffer.put((byte) 4);
		
		write_buffer = serialize(write_buffer, this);
		
		write_buffer = buffer_resize(write_buffer, write_buffer.position());
		
		server_client_list.remove(this);
		
		server_client_map.remove(id);
			
		//Send packet to everyone that a client onDisconnect.
		_bnet_network_send_broadcast_tcp(id, server_client_list, write_buffer, this);
		
		if(!is_ws) {
			tcpServer.udpSessionMap.remove(udpPort);
			
			tcpServer.tcpSessionMap.remove(selKey);
	    	
	    	try {
	    		if(selKey != null) selKey.cancel();
	    		
	    		if(tcpChannel == null) return;
	    		
	    		tcpChannel.close();
	    	}catch(Throwable t) {}
		}else webServer.sessionMap.remove(web_socket);
		
		if(bnet.debug.get()) FileSystem.log(id, "DISCONNECTED");
	}
    
	static void _bnet_network_send_raw(ClientSession client, ByteBuffer source_buffer, int size){
		String id = client.id;
		
		ByteBuffer b = ByteBuffer.allocate(size + 9 + id.length()).order(LITTLE_ENDIAN);
		
		if(client.is_ws) {
			b.put(("BNet1").getBytes());
			b.put((byte) id.length());
			b.putShort((short) size);

			b.put((id + "\0").getBytes());
			
			b.put(source_buffer.array(), 0, size);
			
			Session socket = client.web_socket;
			
			if(socket != null && socket.isOpen()) {
				b.flip();
				
				socket.getRemote().sendBytesByFuture(b);
			}
		}else{
			b.put(("BNet0").getBytes());
			b.put((byte) id.length());
			b.putShort((short) size);

			b.put((id + "\0").getBytes());
			
			b.put(source_buffer.array(), 0, size);
			
			b.flip();
			
			try {client.tcpChannel.write(b);} catch (IOException e1) {}
		}
		
		b = null;
	}
	
	static void _bnet_network_send_broadcast_tcp(String client_id, ArrayList<ClientSession> list, ByteBuffer source_buffer, ClientSession omit){
		int 
		buff_size 	= source_buffer.capacity(),
		size 		= list.size();
		
		ClientSession client;
		
		for(int i = 0; i < size; i++) {
			client = list.get(i);
			
			if(client.equals(omit)) continue;
			
			try {_bnet_network_send_raw(client, source_buffer, buff_size);} catch (Exception e) {}
		}
	}
	
	static void _bnet_network_send_udp_raw(ClientSession client, ByteBuffer source_buffer){
		ArrayList<ByteBuffer> buffer = bnet_buffer_encode(client.id, source_buffer, client.mtu, "0");
		
		for (int i = 0; i < buffer.size(); i++) try {client.udpChannel.send(buffer.get(i).flip(), client.udpSocketAddress);} catch (IOException e) {}
		
		buffer = null;
	}
	
	static void _bnet_network_send_broadcast_udp(String client_id, ArrayList<ClientSession> list, ByteBuffer source_buffer, ClientSession omit){
		ArrayList<ByteBuffer> buffer = bnet_buffer_encode(client_id, source_buffer, 700, "0");
		
		ClientSession client;
		
		int 
		list_size = list.size(),
		buff_size = buffer.size();
		
		for(int i = 0; i < list_size; i++) {
			client = list.get(i);
			
			if(client.equals(omit)) continue;
			
			for (int o = 0; o < buff_size; o++) try {client.udpChannel.send(buffer.get(o).flip(), client.udpSocketAddress);} catch (IOException e) {}
		}
		
		buffer = null;
	}
	
	static ByteBuffer serialize(ByteBuffer buffer, ClientSession client) {
		buffer = buffer_put_bytes(buffer, (client.id +"\0").getBytes());
		buffer = buffer_put_bytes(buffer, (client.name +"\0").getBytes());
		buffer = buffer_put_bytes(buffer, (client.ip + "\0").getBytes());
		buffer = buffer_put_short(buffer, (short) client.tcpPort);
		buffer = buffer_put_short(buffer, (short) client.udpPort);
		buffer = buffer_put_byte(buffer,  (byte) client.ping);
		buffer = buffer_put_bytes(buffer, (client.room == null? "\0": client.room +"\0").getBytes());
		
		return buffer;
	}
	
	static ByteBuffer list_serialize(ByteBuffer buffer, ArrayList<ClientSession> list) {
		int size 	=  list.size();
		
		buffer 		= buffer_put_short(buffer, (short) size);
		
		ClientSession client;
		
		for(int i = 0; i < size; i++) {
			client = list.get(i);
			
			buffer = serialize(buffer, client);
		}
		
		return buffer;
	}
	
	static Instance instance_deserialize(ByteBuffer buffer) {
		Instance instance 		= new Instance();
		
		instance.x 				= buffer.getInt();
		instance.y 				= buffer.getInt();
		instance.depth 			= buffer.getInt();
		instance.object_index 	= read_string(buffer);
		instance.sprite_index 	= read_string(buffer);
		instance.layer 			= read_string(buffer);
		instance.id 			= read_string(buffer);
		instance.owner_id 		= read_string(buffer);
		
		int size 				= Short.toUnsignedInt(buffer.getShort());
		
		for(int i = 0; i < size; i++) {
			instance.create_data.add(read_string(buffer));
			instance.create_data.add(read_string(buffer));
			instance.create_data.add(read_string(buffer));
		}
		
		return instance;
	}
	
	static ByteBuffer instance_serialize(ByteBuffer buffer, Instance instance) {
		buffer = buffer_put_int(buffer, 	instance.x);
		buffer = buffer_put_int(buffer, 	instance.y);
		buffer = buffer_put_int(buffer, 	instance.depth);
		buffer = buffer_put_bytes(buffer, 	(instance.object_index +"\0").getBytes());
		buffer = buffer_put_bytes(buffer, 	(instance.sprite_index +"\0").getBytes());
		buffer = buffer_put_bytes(buffer, 	(instance.layer +"\0").getBytes());
		buffer = buffer_put_bytes(buffer, 	(instance.id +"\0").getBytes());
		buffer = buffer_put_bytes(buffer, 	(instance.owner_id +"\0").getBytes());
		
		int size = instance.create_data.size();
		
		buffer = buffer_put_short(buffer, (short) (size / 3));
		
		for(int i = 0; i < size; i += 3) {
			buffer = buffer_put_bytes(buffer, (instance.create_data.get(i) +"\0").getBytes());
			buffer = buffer_put_bytes(buffer, (instance.create_data.get(i + 1) +"\0").getBytes());
			buffer = buffer_put_bytes(buffer, (instance.create_data.get(i + 2) +"\0").getBytes());
		}
		
		return buffer;
	}
	
	static ByteBuffer instance_list_serialize(ByteBuffer buffer, ArrayList<Instance> list) {
		int size 	= list.size();
		
		buffer 		= buffer_put_short(buffer, (short) size);
		
		Instance instance;
		
		for(int i = 0; i < size; i++) {
			instance = list.get(i);
			
			buffer = instance_serialize(buffer, instance);
		}
		
		return buffer;
	}
	
	void onError(Exception e) {
		//Dump error into a file
		if(bnet.dump_errors.get()) FileSystem.onError(id, e);
		onDisconnect();
	}
	
	static String read_string(ByteBuffer buffer) {
		byte[] array = buffer.array();
		int 
		i 	= buffer.position(),
		pos = i,
		len = array.length;
		
		while(pos < len) {
        	if(String.valueOf((char) array[pos]).equals("\0")) break;
        	pos++;
        }
		
		buffer.position(Math.min(pos + 1, buffer.limit()));
		
		return new String(array, i, pos - i);
	}
	
	static ByteBuffer buffer_put_byte(ByteBuffer src, byte s) {
		
		if(src.remaining() < 1) {
			ByteBuffer b = ByteBuffer.allocate((src.limit()+1) * 2).order(LITTLE_ENDIAN);
			b.put(src.array(), 0, src.limit());
			
			src = b;
		}
		
		src.put(s);
		
		return src;
	}
	
	static ByteBuffer buffer_put_int(ByteBuffer src, int s) {
		int remaining = src.remaining();
		
		if(remaining < 4) {
			ByteBuffer b = ByteBuffer.allocate((src.capacity()+4) * 2).order(LITTLE_ENDIAN);
			b.put(src.array(), 0, src.capacity() - remaining);
			
			src = b;
		}
		
		src.putInt(s);
		
		return src;
	}
	
	static ByteBuffer buffer_put_short(ByteBuffer src, short s) {
		int remaining = src.remaining();
		
		if(remaining < 2) {
			ByteBuffer b = ByteBuffer.allocate((src.capacity()+2) * 2).order(LITTLE_ENDIAN);
			b.put(src.array(), 0, src.capacity() - remaining);
			
			src = b;
		}
		
		src.putShort(s);
		
		return src;
	}
	
	static ByteBuffer buffer_put_long(ByteBuffer src, long s) {
		int remaining = src.remaining();
		
		if(remaining < 8) {
			ByteBuffer b = ByteBuffer.allocate((src.capacity()+8) * 2).order(LITTLE_ENDIAN);
			b.put(src.array(), 0, src.capacity() - remaining);
			
			src = b;
		}
		
		src.putLong(s);
		
		return src;
	}

	
	static ByteBuffer buffer_put_bytes(ByteBuffer src, byte[] arr){
		int 
		remaining = src.remaining(),
		len		  = arr.length;
		
		if(remaining < len) {
			ByteBuffer b = ByteBuffer.allocate((src.capacity() + len) * 2).order(LITTLE_ENDIAN);
			b.put(src.array(), 0, src.capacity() - remaining);
			src = b;
		}
		
		src.put(arr);
		
		return src;
	}
	
	static ByteBuffer buffer_put_bytes(ByteBuffer src, byte[] arr, int offset, int size){
		int remaining 	= src.remaining();
		
		if(remaining < (size - offset)) {
			ByteBuffer b = ByteBuffer.allocate(src.limit() + (size - offset) * 2).order(LITTLE_ENDIAN);
			b.put(src.array(), 0, src.limit() - remaining);
			src = b;
		}
		
		src.put(arr, offset, size);
		
		return src;
	}
	
	static ByteBuffer buffer_resize(ByteBuffer buffer, int size) {
		return ByteBuffer.allocate(size).order(LITTLE_ENDIAN).put(buffer.array(), 0, Math.min(buffer.limit(), size));
	}

	static ArrayList<ByteBuffer> bnet_buffer_encode(String id, ByteBuffer source_buffer, int max_size, String type) {
		boolean debug 		= false;
		int 
		total_size 			= source_buffer.limit(), 
		id_length 			= id.length(),
		target_buffer_size 	= 56 + id_length,
		seek_pos 			= 0, 
		index 				= 0,
		segment_size 		= 0;
		String tag_id;
		tag_id 				= buffer_sha1(source_buffer, 0, total_size);
		
		ArrayList<ByteBuffer> target_buffer = new ArrayList<ByteBuffer>();
		
		// Loop through buffer whiles there's data to be read.
		while (seek_pos < total_size) {
			// Get the target size of how much data I can read from the source buffer compared to how much data can be written to target buffer.
			segment_size = Math.min(total_size - seek_pos, Math.max(1, max_size - target_buffer_size));
			
			// Create a fixed size buffer with headers.
			ByteBuffer buff = ByteBuffer.allocate(target_buffer_size + segment_size).order(LITTLE_ENDIAN);
			
			target_buffer.add(index, buff);
			
			buff.put(("BNet"+type).getBytes());
			buff.put((byte) id_length);
			buff.put((id + "\0").getBytes());
			buff.put((tag_id + "\0").getBytes());
			buff.putShort((short) index);
			buff.putShort((short) segment_size);
			buff.putInt(total_size);
			
			// Copy partial data from source into targeted buffer.
			buff.put(source_buffer.array(), seek_pos, segment_size);
			
			// Update seek position.
			seek_pos += segment_size;
			
			index++;
		}
		// Set buffer tag.
		// target_buffer.get(index).put(tag_id);
		if(debug) System.out.println(seek_pos+"  "+total_size+"  "+target_buffer.size());
		
		return target_buffer;
	}
	
	static String buffer_sha1(ByteBuffer buffer, int offset, int size){
		MessageDigest mDigest = null;
		
		try {
			mDigest = MessageDigest.getInstance("SHA1");
			
			StringBuffer sb = new StringBuffer();
			
			byte[] result = mDigest.digest(buffer.array());
			
			for (int i = 0; i < result.length; i++) {
				sb.append(Integer.toString((result[i] & 0xff) + 0x100, 16).substring(1));
			}
			
			return sb.toString();
		} catch (NoSuchAlgorithmException e) { return "";}
	}
	
	void sendError(String error){
		ByteBuffer buffer = ByteBuffer.allocate(2 + error.length()).order(LITTLE_ENDIAN);
		
		buffer.put((byte) -2);
		buffer.put((error + "\0").getBytes());
		
		_bnet_network_send_raw(this, buffer, buffer.position());
	}
}