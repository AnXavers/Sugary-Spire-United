import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

class Email implements Runnable{
	static final ArrayList<Object[]> task_list 	= new ArrayList<Object[]>();
	
	@Override
	public void run() {
		FileSystem.log("email thread started");
		
		ClientSession client = null;
		ByteBuffer buffer 	= null, write_buffer;
		
		while(bnet.email_active.get()) {			
		try {
			if(!task_list.isEmpty()) {
				Object[] task 		= task_list.get(0);
				
				task_list.remove(0);
				
				if(task != null) {
					client 			= (ClientSession) task[0];
					
					buffer 			= (ByteBuffer) task[1];
					
					String 
					host 			= ClientSession.read_string(buffer), 
					port 			= ClientSession.read_string(buffer), 
					email 			= ClientSession.read_string(buffer),
					password 		= ClientSession.read_string(buffer),
					recipiantsEmail = ClientSession.read_string(buffer),
					subject 		= ClientSession.read_string(buffer), 
					text 			= ClientSession.read_string(buffer),
					attachmentName 	= ClientSession.read_string(buffer);
					int loop 		= Short.toUnsignedInt(buffer.getShort());
					
					byte[] data		= new byte[loop];
					
					for(int i = 0; i < loop; i++) data[i] = buffer.get();
					
					Properties prop = new Properties();
					prop.put("mail.smtp.host", host);
					prop.put("mail.smtp.port", port);
					prop.put("mail.smtp.auth", "true");
					prop.put("mail.smtp.socketFactory.port", port);
					prop.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
					
					javax.mail.Session session = javax.mail.Session.getInstance(prop, new javax.mail.Authenticator() {
						protected PasswordAuthentication getPasswordAuthentication() {
							return new PasswordAuthentication(email, password);
						}
					});
					
					MimeMessage message = new MimeMessage(session);
					
					try {
						message.setFrom(new InternetAddress(email));
						message.addRecipient(Message.RecipientType.TO, new InternetAddress(recipiantsEmail));
						message.setSubject(subject);
						
						if (!attachmentName.equals("")) {
							File file 			 = new File("" + attachmentName);
							FileOutputStream out = new FileOutputStream(file);
							
							out.write(data);
							out.close();
							
							BodyPart messageBodyPart1 = new MimeBodyPart();
							messageBodyPart1.setContent(text, "text/html");
							
							MimeBodyPart messageBodyPart2 	= new MimeBodyPart();
							
							messageBodyPart2.setDataHandler(new DataHandler(new FileDataSource(file)));
							messageBodyPart2.setFileName(attachmentName);
							
							Multipart multipart = new MimeMultipart();
							multipart.addBodyPart(messageBodyPart1);
							multipart.addBodyPart(messageBodyPart2);
							
							message.setContent(multipart);
							
							Transport.send(message);
							file.delete();
							
						} else {
							message.setContent(text, "text/html");
							Transport.send(message);
						}
						
						write_buffer = ByteBuffer.allocate(1).order(ByteOrder.LITTLE_ENDIAN);
						write_buffer.put((byte) 7);
						
						ClientSession._bnet_network_send_raw(client, write_buffer, 1);
						
						if(bnet.debug.get()) FileSystem.log(client.id, "sent an email...");
					} catch (MessagingException | IOException ex) {
						client.sendError("700");
						
						if(bnet.debug.get()) FileSystem.log(client.id, "FAILED TO SEND A EMAIL."+ex.getMessage());
					}
				}
				}
			}catch(Exception e){}
		}
		
		task_list.clear();
		
		bnet.email = null;
		
		FileSystem.log("Email process thread terminated");
	}
}
