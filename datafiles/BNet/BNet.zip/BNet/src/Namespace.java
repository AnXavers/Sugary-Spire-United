import java.util.ArrayList;
import java.util.HashMap;

public class Namespace {
	tcpServer tcpServer;
	webServer webServer;
	
	String name, id;
	
	ArrayList<ClientSession> client_list 		= new ArrayList<ClientSession>();
	
	HashMap <String, ClientSession> client_map 	= new HashMap <String, ClientSession>();
	
	ClientSession owner;
	
	Namespace(tcpServer server){
		tcpServer = server;
	}
	
	Namespace(webServer server){
		webServer = server;
	}
	
	void cleanup() {
		client_list = null;
		client_map 	= null;
		
		if(tcpServer != null) {
			tcpServer.namespace_map.remove(name);
			
			tcpServer.list_map.remove(name);
		}
		
		if(webServer != null) {
			webServer.namespace_map.remove(name);
			
			webServer.list_map.remove(name);
		}
	}
}