import java.util.ArrayList;
import java.util.HashMap;

class Room {
	boolean destroy, migrate;
	
	tcpServer tcpServer;
	
	webServer webServer;
	
	String id;
	
	ClientSession host;
	
	ArrayList<ClientSession> client_list 		= new ArrayList<>();
	HashMap <String, ClientSession> client_map 	= new HashMap <>(); 
	
	ArrayList<Instance> instance_list 			= new ArrayList<>();
	HashMap <String, Instance> instance_map 	= new HashMap <>();
	
	Room(tcpServer server) {
		tcpServer = server;
	}
	
	Room(webServer server){
		webServer = server;
	}
	
	void cleanup() {
		for(int i = 0; i < client_list.size(); i++) {
			client_list.get(i).room = null;
			
			client_list.remove(i);
			
			i--;
		}
		
		if(tcpServer != null) {
			tcpServer.room_map.remove(id);
			
			tcpServer.list_map.remove(id);
		}
		
		if(webServer != null) {
			webServer.room_map.remove(id);
			
			webServer.list_map.remove(id);
		}
		
		client_list 	= null;
		client_map		= null;
		instance_list 	= null;
		instance_map 	= null;
	}
}
