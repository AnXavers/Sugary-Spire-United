import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

class FileSystem implements Runnable {
	static final ArrayList<Object[]> task_list 	= new ArrayList<Object[]>();
	
	static final String 
	main_dir 									= "bnet"+File.separator,
	log_dir 									= main_dir + "logs"+File.separator,
	save_dir 									= main_dir + "client data"+File.separator,
	sys_exc_dir 								= log_dir + "system exceptions"+File.separator,
	sys_log_dir 								= log_dir + "system logs"+File.separator,
	cli_exc_dir 								= log_dir + "client exceptions"+File.separator,
	cli_log_dir 								= log_dir + "client logs"+File.separator,
	db_exc_dir 									= log_dir + "database exceptions"+File.separator,
	db_log_dir 									= log_dir + "database logs"+File.separator; 
	
	static final byte
	log_error									= -1,
	log_system 									= 0;
	
	static FileWriter
	system_exc_writer,
	system_log_writer,
	client_exc_writer,
	client_log_writer,
	database_exc_writer,
	database_log_writer;
	
	static String system_timestamp;
	
	@Override
	public void run() {
		log("bnet initiating file system thread...");
		
		File dir = new File(main_dir);
		
		if(!dir.exists()) dir.mkdirs();
		
		dir = new File(log_dir);
		
		log("bnet checking log directory...");
		
		if(dir.exists()) log("bnet log directory loaded...");
		else {
			dir.mkdirs();
			
			log("bnet created log directory...");
		}
		
		dir = new File(sys_exc_dir);
		
		if(!dir.exists()) dir.mkdirs();
		
		dir = new File(sys_log_dir);
		
		if(!dir.exists()) dir.mkdirs();
		
		dir = new File(cli_exc_dir);
		
		if(!dir.exists()) dir.mkdirs();
		
		dir = new File(cli_log_dir);
		
		if(!dir.exists()) dir.mkdirs();
		
		dir = new File(db_exc_dir);
		
		if(!dir.exists()) dir.mkdirs();
		
		dir = new File(db_log_dir);
		
		if(!dir.exists()) dir.mkdirs();
		
		dir = new File(save_dir);
		
		log("bnet checking client data directory...");
		
		if(dir.exists()) log("bnet client data directory loaded...");
		else {
			dir.mkdirs();
			
			log("bnet created client data directory...");
		}
		
		try {
			String date 		= new SimpleDateFormat("MM-dd").format(new java.util.Date());
			
			system_log_writer 	= new FileWriter(sys_log_dir +date+".text", true);
			system_exc_writer 	= new FileWriter(sys_exc_dir +date+".text", true);
			
			client_log_writer 	= new FileWriter(cli_log_dir +date+".text", true);
			client_exc_writer 	= new FileWriter(cli_exc_dir +date+".text", true);
			
			database_log_writer = new FileWriter(db_log_dir +date+".text", true);
			database_exc_writer = new FileWriter(db_exc_dir +date+".text", true);
		} catch (IOException e1) {log("bnet failed to complete file system setup. "+e1.getMessage());}
		
		ClientSession client;
		ByteBuffer buffer, write_buffer;
		
		while(bnet.filesystem_active.get()) {
			try {
			if(!task_list.isEmpty()) {
				Object[] task 	= task_list.get(0);
				
				if(task != null) {
					client 			= (ClientSession) task[0];
					
					buffer 			= (ByteBuffer) task[1];
					
					switch ((byte) buffer.get()) {
						case 0:// CREATE
							String 
							fname 	= ClientSession.read_string(buffer)+".json",
							data 	= ClientSession.read_string(buffer);
							
							try {
								FileWriter file = new FileWriter(save_dir + fname);
								
								file.write(data);
								
								file.close();
					        
								write_buffer = ByteBuffer.allocate(2).order(ByteOrder.LITTLE_ENDIAN);;
								
								write_buffer.put((byte) 4);
								write_buffer.put((byte) 0);
								
								ClientSession._bnet_network_send_raw(client, write_buffer, 2);
								
								write_buffer = null;
									
								if(bnet.debug.get()) log(client.id,"CREATED A FILE");
						     } catch (IOException e) {
						    	 client.sendError("400");
										
								if(bnet.debug.get()) log(client.id,"FAILED TO CREATE A FILE");
						     }
						break;
						case 1://READ
							String _fname = ClientSession.read_string(buffer)+".json";
							
							try {
								FileReader reader = new FileReader(save_dir+_fname);
								
								String file = "";
								
								int i = 0;
								
								while(reader.ready()) {
									i++;
									file += (char) reader.read();
								}
								
								reader.close();
								
								write_buffer = ByteBuffer.allocate(3 + i).order(ByteOrder.LITTLE_ENDIAN);
								
								write_buffer.put((byte) 4);
								write_buffer.put((byte) 1);
								write_buffer.put((file +"\0").getBytes());
								
								ClientSession._bnet_network_send_raw(client, write_buffer, write_buffer.position());
						        
								write_buffer = null;
								
								file = null;
								
						       if(bnet.debug.get()) log(client.id,"LOADED A FILE");
						     }catch (IOException e) {
						    	client.sendError("401");
								
								if(bnet.debug.get()) log(client.id,"FAILED TO LOAD A FILE");
						      }
						break;
						case 2://UPDATE
							String f = ClientSession.read_string(buffer)+".json";
							try {
								FileWriter file = new FileWriter(save_dir + f);
								
								f = null;
								
								file.write(ClientSession.read_string(buffer));
								
								file.close();
						        
						        write_buffer = ByteBuffer.allocate(2).order(ByteOrder.LITTLE_ENDIAN);;
						        
								write_buffer.put((byte) 4);
								write_buffer.put((byte) 2);
								
								ClientSession._bnet_network_send_raw(client, write_buffer, 2);
								
								write_buffer = null;
						        
								if(bnet.debug.get()) log(client.id,"UPDATED A FILE");
						     }catch (IOException e) {
						    	 client.sendError("402");
								
								if(bnet.debug.get()) log(client.id,"FAILED TO UPDATE A FILE");
						      }
						break;
						case 3://DELETE
							String s = ClientSession.read_string(buffer)+".json";
							
							File file = new File(save_dir + s);
							
							s = null;
							
							if (file.exists()) {
								write_buffer = ByteBuffer.allocate(2).order(ByteOrder.LITTLE_ENDIAN);;
								
								write_buffer.put((byte) 4);
								write_buffer.put((byte) 3);
								
								ClientSession._bnet_network_send_raw(client, write_buffer, 2);
								
								write_buffer = null;
								
								file.delete();
								
								if(bnet.debug.get()) log(client.id,"DELETED A FILE");
							}else {
								client.sendError("403");
								
								if(bnet.debug.get()) log(client.id,"FAILED TO DELETE A FILE. DOESNT EXISTS");
							}
						break;
					}
					
					task_list.remove(0);
				}
			}
			}catch(Exception e) {
				onError(e);
			}
		}
		
		task_list.clear();
		
		bnet.file_system = null;
		
		FileSystem.log("FileSystem process thread terminated");
	}
	
	static void log(String message){
		system_timestamp = new SimpleDateFormat("MM/dd HH:mm:ss").format(new java.util.Date());
		
		System.out.println("["+system_timestamp+ "] "+message);
	}
	
	//System Logger
	static void log(boolean show, String message){
		log(message);
		
		if(bnet.dump_logs.get()) {
			system_timestamp = new SimpleDateFormat("MM/dd HH:mm:ss").format(new java.util.Date());
			
			try{system_log_writer.append("["+system_timestamp+ "] " +message+"\n");} catch (IOException e1) {}
		}
	}
	
	static void onError(Exception e) {
		String exception = e.toString()+ " at ";
		
		for (StackTraceElement element : e.getStackTrace()) exception += element.toString() + "\n";
		
		system_timestamp = new SimpleDateFormat("MM/dd HH:mm:ss").format(new java.util.Date());
		
		if(bnet.dump_errors.get()) {
			//Dump error into a file
			try {system_exc_writer.append("["+system_timestamp+ "] "+exception+"\n"); } catch (IOException e1) {}
		}
		
		if(bnet.debug.get()) log(exception);
	}
	
	static void onError(Throwable e) {
		String exception = e.toString()+ " at ";
		
		for (StackTraceElement element : e.getStackTrace()) exception += element.toString() + "\n";
		
		if(bnet.dump_errors.get()) {
			system_timestamp = new SimpleDateFormat("MM/dd HH:mm:ss").format(new java.util.Date());
		
			//Dump error into a file
			try {system_exc_writer.append("["+system_timestamp+ "] "+exception+"\n"); } catch (IOException e1) {}
		}
		
		if(bnet.debug.get()) log(exception);
	}
	
	//Client Logger
	static void log(String client_id, String message){
		log("{ "+client_id+" } "+message);
			
		if(bnet.dump_logs.get()) {
			system_timestamp = new SimpleDateFormat("MM/dd HH:mm:ss").format(new java.util.Date());
			
			try{client_log_writer.append("["+system_timestamp+ "] { "+client_id+" } " +message+"\n");} catch (IOException e1) {}
		}
	}
	
	static void onError(String id, Exception e) {
		String exception = e.toString()+ " at ";
		
		for (StackTraceElement element : e.getStackTrace()) exception += element.toString() + "\n";
		
		if(bnet.dump_errors.get()) {
			system_timestamp = new SimpleDateFormat("MM/dd HH:mm:ss").format(new java.util.Date());
			
			//Dump error into a file
			try {client_exc_writer.append("["+system_timestamp+ "] { "+id+" } "+exception+"\n"); } catch (IOException e1) {}
		}
		
		if(bnet.debug.get()) log("{ "+id+" } "+exception);
	}
	
	//Database Logger
	static void log(String database, String id, String message){
		log(message);
			
		if(bnet.dump_logs.get()) {
			system_timestamp = new SimpleDateFormat("MM/dd HH:mm:ss").format(new java.util.Date());
			
			try{database_log_writer.append("["+system_timestamp+ "] { "+database+" } { "+id+" }" +message+"\n");} catch (IOException e1) {}
		}
	}
	
	static void onError(String database, String client_id, Exception e) {
		String exception = e.toString()+ " at ";
		
		for (StackTraceElement element : e.getStackTrace()) exception += element.toString() + "\n";
		
		if(bnet.dump_errors.get() || bnet.dump_errors_database.get()) {
			system_timestamp = new SimpleDateFormat("MM/dd HH:mm:ss").format(new java.util.Date());
			
			//Dump error into a file
			if(bnet.dump_errors.get()) try {database_exc_writer.append("["+system_timestamp+ "] { "+database+" } { "+client_id+" }" +exception+"\n");} catch (IOException e1) {}
			
			if(bnet.dump_errors_database.get()) {
				
			}
		}
	}
}