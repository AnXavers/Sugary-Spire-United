import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;

import org.bson.Document;

import com.mongodb.MongoException;
import com.mongodb.client.ListCollectionsIterable;
import com.mongodb.client.ListDatabasesIterable;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Updates;

class Database implements Runnable{
	static final ArrayList<Object[]>
	task_list 									= new ArrayList<Object[]>(),
	system_task_list 							= new ArrayList<Object[]>();
	
	static MongoClient mongoClient;
	String 
	name  										= "DEFAULT",
	connect_string;
	
	Database(String connect_string) throws Exception{
		this.connect_string = connect_string;
		mongoClient 		= MongoClients.create(connect_string);
			
		//Verify that connection successful.
		mongoClient.listDatabases().first();
		
		FileSystem.log(true, "bnet connected to mongodb.");
	}
	
	@Override
	public void run() {
		String 
		database_name,
		collection_name,
		key;
		
		MongoDatabase db;
		MongoCollection<Document> c;
		
		ClientSession client = null;
		ByteBuffer buffer 	 = null, write_buffer;
		
		while(bnet.database_active.get()) {
			try {
			if(!task_list.isEmpty()) {
				Object[] task 		= task_list.get(0);
				
				if(task != null) {
					client 			= (ClientSession) task[0];
					
					buffer 			= (ByteBuffer) task[1];
				
					switch((byte) buffer.get()){
						case 0://DATABASE
							switch((byte) buffer.get()) {
								case 0://CREATE
									if(mongoClient != null) {
										try {mongoClient.getDatabase(ClientSession.read_string(buffer));}catch(IllegalArgumentException e) {
											sendError(client, "600");
											
											if(bnet.debug.get()) FileSystem.log(name, client.id, "FAILED TO CREATE DATABASE "+e.getMessage());
											
											break;
										}
										
										ClientSession._bnet_network_send_raw(client, buffer, buffer.limit());
										
										if(bnet.debug.get()) FileSystem.log(name, client.id, "CREATED A DATABASE");
									}else if(bnet.debug.get()) FileSystem.log(name, client.id, "CREATE DATABASE FAILED. NOT CONNECTED TO MONGODB. see 'bnet mongodb help' .");
								break;
								case 1://GET DATABASE(S)
									if(mongoClient != null) {
										database_name = ClientSession.read_string(buffer);
										
										ArrayList<String> list  = new ArrayList<>();
										
										if(database_name.equals("")) {
											ListDatabasesIterable<Document> bl = mongoClient.listDatabases();
											
											for(Document dd: bl) list.add(dd.toJson());
											
											if(bnet.debug.get()) FileSystem.log(name, client.id, "REQUESTED ALL DATABASES");
										}else{
											try{
												list.add(mongoClient.getDatabase(database_name).toString());
												
												if(bnet.debug.get()) FileSystem.log(name, client.id, "REQUESTED A DATABASE");
											}catch(MongoException | IllegalArgumentException e) {
												sendError(client, "601");
												
												if(bnet.debug.get()) FileSystem.log(name, client.id, "FAILED TO GET DATABASE "+e.getMessage());
												
												list = null;
												
												break;
											}
										}
										
										write_buffer = ByteBuffer.allocate(6 + database_name.length()).order(ByteOrder.LITTLE_ENDIAN);
										
										write_buffer.put((byte) 6);
										write_buffer.put((byte) 0);
										write_buffer.put((byte) 1);
										write_buffer.put((database_name + "\0").getBytes());
										write_buffer.putShort((short) list.size());
							    	   
										for(String dbb: list) write_buffer = ClientSession.buffer_put_bytes(write_buffer, (dbb + "\0").getBytes());
										
										ClientSession._bnet_network_send_raw(client, write_buffer, write_buffer.position());
							       }else if(bnet.debug.get()) FileSystem.log(name, client.id, "GET DATABASE FAILED. NOT CONNECTED TO MONGODB. see 'bnet mongodb help' .");
								break;
								case 2://DESTROY
									if(mongoClient != null) {
										database_name = ClientSession.read_string(buffer);
										
										try { db = mongoClient.getDatabase(database_name);}catch(MongoException | IllegalArgumentException e) {
											sendError(client, "602");
											
											if(bnet.debug.get()) FileSystem.log(name, client.id, "FAILED TO DESTROY DATABASE "+e.getMessage());
											
											break;
										}
										
										db.drop();
										
										ClientSession._bnet_network_send_raw(client, buffer, buffer.limit());
								    	   
								    	if(bnet.debug.get()) FileSystem.log(name, client.id, "REQUESTED TO DESTROY A DATABASE");
									}else if(bnet.debug.get()) FileSystem.log(name, client.id, "GET DATABASE FAILED. NOT CONNECTED TO MONGODB. see 'bnet mongodb help' .");
								break;
							}
						break;
						case 1://COLLECTIONS
							switch((byte) buffer.get()) {
								case 0://CREATE
									if(mongoClient != null) {
										try { mongoClient.getDatabase(ClientSession.read_string(buffer)).createCollection(ClientSession.read_string(buffer));}catch(MongoException | IllegalArgumentException e){
											
											sendError(client, "603");
											
											if(bnet.debug.get()) FileSystem.log(name, client.id, "CREATE COLLECTION FAILED "+e.getMessage());
											
											break;
										}
										
										ClientSession._bnet_network_send_raw(client, buffer, buffer.limit());
										
										if(bnet.debug.get()) FileSystem.log(name, client.id, "CREATED A COLLECTION");
									}else if(bnet.debug.get()) FileSystem.log(name, client.id, "FAILED TO CREATE A COLLECTION, MONGODB CONNECT HASNT BEEN INITIATED. see 'bnet mongodb help' .");
								break;
								case 1://GET
									if(mongoClient != null) {
										String dbn 	= ClientSession.read_string(buffer);
										
										db 			= getDataBase(name, client.id, dbn);
										
										if(db != null) {
											collection_name 			= ClientSession.read_string(buffer);
											ArrayList<String> doc_list  = new ArrayList<>();
											
											if(collection_name.equals("")) {
												ListCollectionsIterable<Document> bl = db.listCollections();
												
												for(Document dd: bl) doc_list.add(dd.toJson());
												
												if(bnet.debug.get()) FileSystem.log(name, client.id, "REQUESTED ALL COLLECTIONS WITHIN A DATABASE");
											}else{
												try{
													doc_list.add(db.getCollection(collection_name).toString());
													
													if(bnet.debug.get()) FileSystem.log(name, client.id, "REQUESTED A COLLECTION");
												}catch(MongoException | IllegalArgumentException e) {
													sendError(client, "604");
													
													if(bnet.debug.get()) FileSystem.log(name, client.id, "FAILED TO GET A COLLECTION "+e.getMessage());
													
													break;
												}
											}
											
											write_buffer = ByteBuffer.allocate(7 + dbn.length() + collection_name.length()).order(ByteOrder.LITTLE_ENDIAN);
											
											write_buffer.put((byte) 6);
											write_buffer.put((byte) 1);
											write_buffer.put((byte) 1);
											write_buffer.put((dbn + "\0").getBytes());
											write_buffer.put((collection_name + "\0").getBytes());
											write_buffer.putShort((short) doc_list.size());
								    	   
											String doc;
											int size = doc_list.size();
											
											for(int i = 0; i < size; i++) {
												doc = doc_list.get(i);
												
												write_buffer = ClientSession.buffer_put_bytes(write_buffer, (doc + "\0").getBytes());
											}
											
											ClientSession._bnet_network_send_raw(client, write_buffer, write_buffer.position());
											
										}else {
											sendError(client, "605");
											
											if(bnet.debug.get()) FileSystem.log(name, client.id, "FAILED TO GET COLLECTION FROM DATABASE. DATABASE DOESNT EXISTS");
											
											break;
										}
									}else if(bnet.debug.get()) FileSystem.log(name, client.id, "FAILED TO GET A COLLECTION MONGODB. HASNT BEEN INITIATED. see 'bnet mongodb help' .");
								break;
								case 2://DESTROY
									if(mongoClient != null) {
										db 	= getDataBase(name, client.id, ClientSession.read_string(buffer));
										
										if(db != null) {
											try {db.getCollection(ClientSession.read_string(buffer)).drop();}catch(IllegalArgumentException e) {
												sendError(client, "606");
												
												if(bnet.debug.get()) FileSystem.log(name, client.id, "FAILED TO DESTROY A COLLECTION "+e.getMessage());
												
												break;
											}
											
											ClientSession._bnet_network_send_raw(client, buffer, buffer.limit());
											
											if(bnet.debug.get()) FileSystem.log(name, client.id, "DESTROYED A COLLECTION");
										}else {
											sendError(client,"607");
											
											if(bnet.debug.get()) FileSystem.log(name, client.id, "FAILED TO DESTROY COLLECTION FROM DATABASE. DATABASE DOESNT EXISTS");
											
											break;
										}
									}else if(bnet.debug.get()) FileSystem.log(name, client.id, "FAILED TO DESTROY A COLLECTION. MONGODB HASNT BEEN INITIATED. see 'bnet mongodb help' .");
								break;
							}
						break;
						case 2://DOCUMENT
							switch((byte) buffer.get()) {
								case 0: //CREATE
									if(mongoClient != null) {
										db = getDataBase(name, client.id, ClientSession.read_string(buffer));
										
										if(db != null) {
											try { c = db.getCollection(ClientSession.read_string(buffer));}catch(IllegalArgumentException e) {
												sendError(client, "608");
												
												if(bnet.debug.get()) FileSystem.log(name, client.id, "FAILED TO CREATE A DOCUMENT. INVALID COLLECTION "+e.getMessage());
												
												break;
											}
												
											try { c.insertOne(new Document("_id", ClientSession.read_string(buffer)));}catch(MongoException | IllegalArgumentException e) {
												sendError(client, "609");
												
												if(bnet.debug.get()) FileSystem.log(name, client.id, "FAILED TO CREATE A DOCUMENT "+e.getMessage());
												
												break;
											}
											
											ClientSession._bnet_network_send_raw(client, buffer, buffer.limit());
											
											if(bnet.debug.get()) FileSystem.log(name, client.id, "CREATED A DOCUMENT");
											
										}else {
											sendError(client, "610");
											
											if(bnet.debug.get()) FileSystem.log(name, client.id, "FAILED TO CREATE A DOCUMENT. DATABASE DOESNT EXISTS");
											
											break;
										}
									}else if(bnet.debug.get()) FileSystem.log(name, client.id, "FAILED TO CREATE A DOCUMENT. MONGODB HASNT BEEN INITIATED. see 'bnet mongodb help' .");
								break;
								case 1://GET
									if(mongoClient != null) {
										String dbn = ClientSession.read_string(buffer);
										
										db = getDataBase(name, client.id, dbn);
										
										if(db != null) {
											String cn = ClientSession.read_string(buffer);
											
											try {c = db.getCollection(cn);}catch(IllegalArgumentException e) {
												sendError(client, "611");
												
												if(bnet.debug.get()) FileSystem.log(name, client.id, "FAILED TO GET A DOCUMENT "+e.getMessage());
												
												break;
											}
												
											key = ClientSession.read_string(buffer);
											
											ArrayList<Document> doc_list  = new ArrayList<>();
											
											if(key.equals("")) {
												c.find().into(doc_list);
												
												if(bnet.debug.get()) FileSystem.log(name, client.id, "REQUESTED ALL DOCUMENTS WITHIN A COLLECTION");
											}else{
												Document d = c.find(Filters.eq("_id", key)).first();
												
												if(d != null) doc_list.add(d);
												else {
													sendError(client, "612");
													
													if(bnet.debug.get()) FileSystem.log(name, client.id, "FAILED TO GET A DOCUMENT DOESNT EXISTS");
													
													break;
												}
												
												if(bnet.debug.get()) FileSystem.log(name, client.id, "REQUESTED A DOCUMENT");
											}
											
											int size = doc_list.size();
											
											write_buffer = ByteBuffer.allocate(8 + dbn.length() + cn.length() + key.length()).order(ByteOrder.LITTLE_ENDIAN);
											
											write_buffer.put((byte) 6);
											write_buffer.put((byte) 2);
											write_buffer.put((byte) 1);
											write_buffer.put((dbn + "\0").getBytes());
											write_buffer.put((cn + "\0").getBytes());
											write_buffer.put((key + "\0").getBytes());
											write_buffer.putShort((short) size);
								    	   
											Document doc;
											
											for(int i = 0; i < size; i++) {
												doc = doc_list.get(i);
												
												write_buffer = ClientSession.buffer_put_bytes(write_buffer, (doc.toJson() + "\0").getBytes());
											}
											
											ClientSession._bnet_network_send_raw(client, write_buffer, write_buffer.position());
										}else {
											sendError(client, "613");
											
											if(bnet.debug.get()) FileSystem.log(name, client.id, "FAILED TO GET A DOCUMENT FROM DATABASE. DATABASE DOESNT EXISTS");
										}
									}else if(bnet.debug.get()) FileSystem.log(name, client.id, "FAILED TO GET A DOCUMENT FROM DATABASE. MONGODB HASNT BEEN INITIATED. see 'bnet mongodb help' .");
								break;
								case 2://SET
									if(mongoClient != null) {
										db = getDataBase(name, client.id, ClientSession.read_string(buffer));
										
										if(db != null) {
											try {c = db.getCollection(ClientSession.read_string(buffer));}catch(IllegalArgumentException e){
												sendError(client, "614");
												
												if(bnet.debug.get()) FileSystem.log(name, client.id, "FAILED TO SET A KEY VALUE TO A DOCUMENT. "+e.getMessage());
												
												break;
											}
												
											String ds = ClientSession.read_string(buffer);
											
											try{c.updateOne(Filters.eq("_id", ds), Updates.combine(Updates.set(ClientSession.read_string(buffer), ClientSession.read_string(buffer))));}
											catch(MongoException e) {
												sendError(client, "615");
												
												if(bnet.debug.get()) FileSystem.log(name, client.id, "FAILED TO SET A KEY VALUE TO A DOCUMENT. "+e.getMessage());
												
												break;
											}
												
											ClientSession._bnet_network_send_raw(client, buffer, buffer.limit());
												
											if(bnet.debug.get()) FileSystem.log(name, client.id, "SET A KEY VALUE TO DOCUMENT");
											
										}else {
											sendError(client, "616");
											
											if(bnet.debug.get()) FileSystem.log(name, client.id, "FAILED TO SET A KEY VALUE TO A DOCUMENT. DATABASE DOESNT EXISTS");
											
											break;
										}
									}else if(bnet.debug.get()) FileSystem.log(name, client.id, "FAILED TO SET A KEY VALUE TO A DOCUMENT. MONGODB HASNT BEEN INITIATED. see 'bnet mongodb help' .");
								break;
								case 3://UNSET
									if(mongoClient != null) {
										db = getDataBase(name, client.id, ClientSession.read_string(buffer));
										
										if(db != null) {
											try {c = db.getCollection(ClientSession.read_string(buffer));}catch(IllegalArgumentException e){
												sendError(client, "617");
												
												if(bnet.debug.get()) FileSystem.log(name, client.id, "FAILED TO DELETE A KEY FROM A DOCUMENT. "+e.getMessage());
												
												break;
											}
												
											String ds = ClientSession.read_string(buffer);
											
											try{
												c.updateOne(Filters.eq("_id", ds), Updates.combine(Updates.unset(ClientSession.read_string(buffer))));
												
												ClientSession._bnet_network_send_raw(client, buffer, buffer.limit());
												
												if(bnet.debug.get()) FileSystem.log(name, client.id, "DELETED A KEY FROM A DOCUMENT");
											}catch(MongoException e) {
												sendError(client, "618");
												
												if(bnet.debug.get()) FileSystem.log(name, client.id, "FAILED TO DELETE A KEY FROM A DOCUMENT. "+e.getMessage());
												
												break;
											}
										}else {
											sendError(client, "619");
											
											if(bnet.debug.get()) FileSystem.log(name, client.id, "FAILED TO DELETE A KEY FROM A DOCUMENT. DATABASE DOESNT EXISTS");
											
											break;
										}
									}else if(bnet.debug.get()) FileSystem.log(name, client.id, "FAILED TO DELETE A KEY FROM A DOCUMENT. MONGODB HASNT BEEN INITIATED. see 'bnet mongodb help' .");
								break;
								case 4://PUSH
									if(mongoClient != null) {
										db = getDataBase(name, client.id, ClientSession.read_string(buffer));
										
										if(db != null) {
											try {c = db.getCollection(ClientSession.read_string(buffer));}catch(IllegalArgumentException e){
												sendError(client, "620");
												
												if(bnet.debug.get()) FileSystem.log(name, client.id, "FAILED TO PUSH A KEY VALUE TO A DOCUMENT. "+e.getMessage());
												
												break;
											}
												
											String ds = ClientSession.read_string(buffer);
											
											try{
												c.updateOne(Filters.eq("_id", ds), Updates.combine(Updates.push(ClientSession.read_string(buffer), ClientSession.read_string(buffer))));
												
												ClientSession._bnet_network_send_raw(client, buffer, buffer.limit());
												
												if(bnet.debug.get()) FileSystem.log(name, client.id, "PUSHED A KEY VALUE TO DOCUMENT");
											}catch(MongoException e) {
												sendError(client, "621");
												
												if(bnet.debug.get()) FileSystem.log(name, client.id, "FAILED TO PUSH A KEY VALUE TO A DOCUMENT. "+e.getMessage());
											}
											
										}else {
											sendError(client, "622");
											
											if(bnet.debug.get()) FileSystem.log(name, client.id, "FAILED TO PUSH A KEY VALUE TO A DOCUMENT. DATABASE DOESNT EXISTS");
										}
									}else if(bnet.debug.get()) FileSystem.log(name, client.id, "FAILED TO PUSH A KEY VALUE TO A DOCUMENT. MONGODB HASNT BEEN INITIATED. see 'bnet mongodb help' .");
								break;
								case 5://PULL
									if(mongoClient != null) {
										db = getDataBase(name, client.id, ClientSession.read_string(buffer));
										
										if(db != null) {
											try {c = db.getCollection(ClientSession.read_string(buffer));}catch(IllegalArgumentException | MongoException e){
												sendError(client, "623");
												
												if(bnet.debug.get()) FileSystem.log(name, client.id, "FAILED TO DELETE A VALUE FROM WITHIN A ARRAY. "+e.getMessage());
												
												break;
											}
												
											String ds = ClientSession.read_string(buffer);
											
											try {
												c.updateOne(Filters.eq("_id", ds), Updates.combine(Updates.pull(ClientSession.read_string(buffer), ClientSession.read_string(buffer))));
												
												ClientSession._bnet_network_send_raw(client, buffer, buffer.limit());
												
												if(bnet.debug.get()) FileSystem.log(name, client.id, "DELETED A VALUE FROM WITHIN A ARRAY");
											}catch(MongoException e) {
												sendError(client, "624");
												
												if(bnet.debug.get()) FileSystem.log(name, client.id, "FAILED TO DELETE A VALUE FROM WITHIN A ARRAY. "+e.getMessage());
											}
											
										}else {
											sendError(client, "625");
											
											if(bnet.debug.get()) FileSystem.log(name, client.id, "FAILED TO DELETE A VALUE FROM WITHIN A ARRAY. DATABASE DOESNT EXISTS");
										}
									}else if(bnet.debug.get()) FileSystem.log(name, client.id, "FAILED TO DELETE A VALUE FROM WITHIN A ARRAY. MONGODB HASNT BEEN INITIATED. see 'bnet mongodb help' .");
								break;
								case 6://DESTROY
									if(mongoClient != null) {
										db = getDataBase(name, client.id, ClientSession.read_string(buffer));
										
										if(db != null) {
											try {c = db.getCollection(ClientSession.read_string(buffer));}catch(IllegalArgumentException e){
												sendError(client, "626");
												
												if(bnet.debug.get()) FileSystem.log(name, client.id, "FAILED TO DESTROY A DOCUMENT. "+e.getMessage());
												
												break;
											}
												
											String ds = ClientSession.read_string(buffer);
											
											try{
												c.deleteOne(Filters.eq("_id", ds));
												
												ClientSession._bnet_network_send_raw(client, buffer, buffer.limit());
												
												if(bnet.debug.get()) FileSystem.log(name, client.id, "DESTROYED A DOCUMENT");
											}catch(MongoException e) {
												sendError(client, "627");
												
												if(bnet.debug.get()) FileSystem.log(name, client.id, "FAILED TO DESTROY A DOCUMENT. "+e.getMessage());
											}
										}else {
											sendError(client, "628");
											
											if(bnet.debug.get()) FileSystem.log(name, client.id, "FAILED TO DESTROY A DOCUMENT. DATABASE DOESNT EXISTS");
										}
									}else if(bnet.debug.get()) FileSystem.log(name, client.id, "FAILED TO DESTROY A DOCUMENT. MONGODB HASNT BEEN INITIATED. see 'bnet mongodb help' .");
								break;
							}
						break;
					}
				}
				
				task_list.remove(0);
			}
			
			}catch(Exception e){if(bnet.dump_errors.get()) FileSystem.onError(name, "", e);}
		}
		
		task_list.clear();
		
		mongoClient.close();
		
		mongoClient = null;
		
		bnet.database = null;
		
		FileSystem.log(true, "bnet disconnected from mongodb.");
	}
	
	void sendError(ClientSession client, String error){
		ByteBuffer buffer = ByteBuffer.allocate(2 + error.length()).order(ByteOrder.LITTLE_ENDIAN);
		
		buffer.put((byte) -2);
		buffer.put((error + "\0").getBytes());
		
		ClientSession._bnet_network_send_raw(client, buffer, buffer.position());
	}
	
	static MongoDatabase getDataBase(String name, String client_id, String database) {
		try {return mongoClient.getDatabase(database);}
		catch (IllegalArgumentException e) {
			if(bnet.dump_errors.get()) FileSystem.onError(name, client_id, e);
			
			return null;
		}
	}
}
