import java.util.ArrayList;

class Instance {
	String id, layer, owner_id, object_index, sprite_index;
	
	int x, y, depth;
	
	ArrayList<String> create_data = new ArrayList<>();
}