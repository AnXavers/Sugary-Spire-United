import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.UUID;

import org.eclipse.jetty.websocket.api.Session;
import org.eclipse.jetty.websocket.api.annotations.OnWebSocketClose;
import org.eclipse.jetty.websocket.api.annotations.OnWebSocketConnect;
import org.eclipse.jetty.websocket.api.annotations.OnWebSocketError;
import org.eclipse.jetty.websocket.api.annotations.OnWebSocketMessage;
import org.eclipse.jetty.websocket.api.annotations.WebSocket;

import spark.Service;

@WebSocket
public class webServer implements Runnable {
	HashMap<String, Object> map;
	
	//Store all connected clients.
	final HashMap<Session, ClientSession> 
	sessionMap 											= new HashMap<Session, ClientSession>();
		
	//Store all clients registered on server.
	HashMap<String, ClientSession> client_map 			= new HashMap <String, ClientSession>();
	ArrayList<ClientSession> client_list 				= new ArrayList<ClientSession>();
	
	//Store all client list here.
	HashMap<String, ArrayList<ClientSession>> list_map 	= new HashMap <String, ArrayList<ClientSession>>();
	
	HashMap<String, Room> room_map						= new HashMap <String, Room>();
	HashMap<String, Namespace> namespace_map 			= new HashMap <String, Namespace>();
	
	Service server										= Service.ignite();
	
	String
	client_list_uuid									= UUID.randomUUID().toString(),
	id,
	ip,
	version;
	
	int fps, shutdown_alarm = 1, congestion_threshold, port;
	
	boolean running 									= false;
	
	final ArrayList<Session> 
	onConnect 											= new ArrayList<Session>(),
	onClose 											= new ArrayList<Session>();
	
	final ArrayList<Object[]>
	onMessage 											= new ArrayList<Object[]>();
	
	webServer(String type, String id, String ip, int port, int max_clients, String version, int fps, String keystoreFilePath, String keystorePassword, String truststoreFilePath, String truststorePassword) throws Exception{
		this.id 		= id;
		this.fps 		= fps;
		this.version 	= version;
		this.port 		= port;
		this.ip  		= ip;
		
		list_map.put(client_list_uuid, client_list);
		
		server.threadPool(max_clients);
		
		if(type.equals("wss")) server.secure(keystoreFilePath, keystorePassword, truststoreFilePath, truststorePassword);
		
		server.ipAddress(ip);
 		
		server.port(port);
		
		server.webSocket("/", this);
		
		server.init();
		
		running = true;
	}
	
	@Override
	public void run() {
		FileSystem.log("bnet server listening on ip: "+ip+" || web port: "+port);
		
		while(shutdown_alarm > 0) {
			if(!running) shutdown_alarm--;
			
			synchronized(onMessage) {
				if(onMessage.size() > 0) {
					Object[] arr = onMessage.get(0);
					
					ClientSession client = sessionMap.get(arr[0]);
					
					if(client != null) client.onWebRead(ByteBuffer.allocate((int) arr[2]).put((byte[]) arr[1]).flip().order(ByteOrder.LITTLE_ENDIAN));
					
					onMessage.remove(0);
				}
			}
			
			synchronized(onConnect) {
				if(onConnect.size() > 0) {
					Session session  = onConnect.get(0);
					
					if(session.isOpen()) sessionMap.put(session, new ClientSession(this, session));
					
					onConnect.remove(0);
				}
			}
			
			synchronized(onClose) {
				if(onClose.size() > 0) {
					ClientSession client = sessionMap.get(onClose.get(0));
					
					if(client != null) client.onDisconnect();
					
					onClose.remove(0);
				}
			}
		}
		
		server.stop();
		
		synchronized(bnet.server_map) {bnet.server_map.remove(id);}
		
		synchronized(bnet.server_list) {bnet.server_list.remove(this);}
		
		FileSystem.log("bnet server terminated");
	}
	
	@OnWebSocketConnect
	public void onConnect(Session session){ synchronized(onConnect) {onConnect.add(session);}}
	
	@OnWebSocketClose
	public void onClose(Session session, int statusCode, String reason) {synchronized(onClose) {onClose.add(session);}}
	
	@OnWebSocketMessage
	public void onMessage(Session session, byte[] b, int offset, int length){synchronized(onMessage) {onMessage.add(new Object[] {session, b, length});}}

	@OnWebSocketError
	public void onError(Session session, Throwable e) {
		synchronized(onClose) {onClose.add(session);}
		
		FileSystem.onError(e);
	}
	
	void onShutDown(int alarm){
    	FileSystem.log("bnet terminating server");
    	
		running 		= false;
		
    	shutdown_alarm 	= alarm * (fps*10);
	
		//BROADCAST A MESSAGE TO EVERY CLIENT THAT THE SERVER IS BEING DESTROYED.
		ByteBuffer write_buffer = ByteBuffer.allocate(6).order(ByteOrder.LITTLE_ENDIAN);
	
		write_buffer.put((byte) 0);
		write_buffer.put((byte) -2);
		write_buffer.putInt(alarm);
		
		ClientSession._bnet_network_send_broadcast_tcp("", client_list, write_buffer, null);
    }
}