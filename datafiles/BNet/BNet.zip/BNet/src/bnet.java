/*
BY: BAHAMAGAMES
contacts for further assistance!!!
email: bahamagames@gmail.com 
discord: rickky#1696

version: 2.0.0
last updated: 4/ 30/ 2022

Non maven files are not allowed to be shared. thanks :D
*/

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

import org.jline.reader.EndOfFileException;
import org.jline.reader.LineReader;
import org.jline.reader.LineReaderBuilder;
import org.jline.reader.UserInterruptException;
import org.jline.terminal.Terminal;
import org.jline.terminal.TerminalBuilder;
import org.slf4j.LoggerFactory;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.LoggerContext;
import picocli.CommandLine;

class bnet{
	static final ProcessHandle currentProcess 	= ProcessHandle.current();
	
	static final ExecutorService thread_pool 	= Executors.newCachedThreadPool();
	static Thread database, file_system, email;
	
	static HashMap<String, HashMap<String, Object>> server_map 	= new HashMap<String, HashMap<String, Object>>();
	static final ArrayList<Object> server_list		= new ArrayList<Object>();
	
	static AtomicBoolean
	debug 										= new AtomicBoolean(false),
	dump_logs 									= new AtomicBoolean(false),
	dump_errors 								= new AtomicBoolean(false),
	dump_logs_database 							= new AtomicBoolean(false),
	dump_errors_database 						= new AtomicBoolean(false),
	database_active 							= new AtomicBoolean(false),
	email_active 								= new AtomicBoolean(false),
	filesystem_active 							= new AtomicBoolean(true);
	
	public static void main(String args[]){
		System.setProperty("org.eclipse.jetty.util.log.class", "org.eclipse.jetty.util.log.StdErrLog");
		System.setProperty("org.eclipse.jetty.LEVEL", "OFF");
		LoggerContext loggerContext = (LoggerContext) LoggerFactory.getILoggerFactory();
	 	org.slf4j.Logger mongoLogger = loggerContext.getLogger("org.mongodb.driver");
	 	org.slf4j.Logger jettyLogger = loggerContext.getLogger("org.eclipse.jetty.util.log.StdErrLog");
	 	org.slf4j.Logger sparkLogger = loggerContext.getLogger("spark.embeddedserver.jetty.EmbeddedJettyServer");
	 	((Logger) jettyLogger).setLevel(Level.OFF);
	 	((Logger) mongoLogger).setLevel(Level.OFF);
	 	((Logger) sparkLogger).setLevel(Level.OFF);
	 	
		init();
		
	 	String prompt = "bnet> "; 
		
		try {
		TerminalBuilder builder = TerminalBuilder.builder(); 
		Terminal terminal 		= builder.system(true).build(); 
		LineReader reader 		= LineReaderBuilder.builder().terminal(terminal).build();
		
		while (true) {
			String line = null;
			try { 
				line = reader.readLine(prompt);
				
			} catch (UserInterruptException e) { 
				terminal.writer().println("User Interruption !");
			} catch (EndOfFileException e) {FileSystem.onError(e); return; } 

			if (line == null) continue;

			line = line.trim(); 

			terminal.flush(); 

			//if (line.equalsIgnoreCase("quit") || line.equalsIgnoreCase("exit")) break;
			
			new CommandLine(new CliCommands()).execute(line.split(" "));
		}

		}catch(IOException e) {FileSystem.onError(e);}
	}
	
	static void init() {
		FileSystem.log("bnet started. See 'bnet -h, --help' for help.");
	}
}
