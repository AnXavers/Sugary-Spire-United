import java.util.HashMap;
import org.json.JSONObject;
import picocli.CommandLine.Command;
import picocli.CommandLine.Option;
import picocli.CommandLine.Parameters;

@Command(name = "bnet", 
		description = "\n@|green BNet (BahamasNet) a lightweight Gms(GameMakerStudio) network framework|@.\n", 
		version = {"@|yellow Version 2.0.0|@", "@|green,bg(red) (c) 2019|@" },  
		mixinStandardHelpOptions = true,
		subcommands = {MongodbCli.class, ServerCli.class, EmailCli.class, FileSystemCli.class}
		)
public class CliCommands implements Runnable{
	@Option(names = {"-d", "--debug"}, defaultValue = "false", description = "Display debug messages.")
	static boolean db(boolean enable) {
		bnet.debug.set(enable);
		
		return true;
	}
	
	
	@Option(names = {"-dl", "--dumpLogs"}, defaultValue = "false", description = "Dump messages to directory.")
	static boolean dl(boolean enable) {
		bnet.dump_logs.set(enable);
		
		return false;
	}
	
	@Option(names = {"-de", "--dumpErrors"}, defaultValue = "false", description = "Dump errors to directory.")
	static String de;
	static boolean de(boolean enable) {
		bnet.dump_errors.set(enable);
		
		return false;
	}
	
	public void run() {}
}

@Command(name = "file", mixinStandardHelpOptions = true, description = "Manage file system processing thread.")
class FileSystemCli implements Runnable{
	@Command(name = "start", description = "Starts file system processing thread.")
	public boolean start() {
		bnet.filesystem_active.set(true);
		
		bnet.file_system = new Thread(new FileSystem(), "FileSystem");
	 	bnet.file_system.setDaemon(true);
	 	bnet.file_system.start();
	 	
		return true;
	}
	
	@Command(name = "stop", description = "Stops email processing thread.")
	public boolean stop() {
		FileSystem.log("Terminating file system process thread");
		
		bnet.filesystem_active.set(false);
	 	
		return true;
	}
	
	@Override
	public void run() {}
}

@Command(name = "email", mixinStandardHelpOptions = true, description = "Manage email processing thread.")
class EmailCli implements Runnable{
	@Command(name = "start", description = "Starts email processing thread.")
	public boolean start() {
		bnet.email_active.set(true);
		
		bnet.email = new Thread(new Email(), "Email");
		bnet.email.setDaemon(true);
		bnet.email.start();
	 	
		return true;
	}
	
	@Command(name = "stop", description = "Stops email processing thread.")
	public boolean stop() {
		FileSystem.log("Terminating email process thread");
		
		bnet.email_active.set(false);
	 	
		return true;
	}
	
	@Override
	public void run() {
		
	}
}

@Command(name = "mongo", mixinStandardHelpOptions = true, description = "Manage connection to mongoDB cluster.")
class MongodbCli implements Runnable{
	
	@Option(names = {"-c"," --connect"}, description = "Connect to mongoDB: 'connection url'.")
	public Integer connect(@Parameters(arity = "1", paramLabel = "connection string") String url) {
		if(!bnet.database_active.get()) {
			FileSystem.log(bnet.debug.get(), "bnet attemping to initiate connection to database, please wait...");
			
			try {
				bnet.database = new Thread(new Database(url), "DataBase");

				bnet.database_active.set(true);
				bnet.database.setDaemon(true);
				bnet.database.start();
				
			}catch(Exception e){
				bnet.database_active.set(false);
				
				FileSystem.log(bnet.debug.get(), "bnet failed to connect to mongodb. "+e.getMessage());
				
				FileSystem.onError(e);
			}
		}else FileSystem.log("bnet already connected to mongodb.");
		return 0;
	}
	
	@Option(names = {"-d"," --disconnect"}, description = "Disonnect from mongoDB.")
	public boolean disconnect(boolean dis) {
		if(bnet.database_active.get()) {
			FileSystem.log(bnet.debug.get(), "bnet started disconnection from mongodb, please wait...");
			
			bnet.database_active.set(false);
		}else FileSystem.log("bnet already disconnected from mongodb.");
		
		return true;
	}
	
	@Override
	public void run() {}
}

@Command(name = "server", mixinStandardHelpOptions = true, description = "Manage a relay server(s) specfically built for GMS(GameMakerStudio)")
class ServerCli implements Runnable{
	
	@Command(name = "list", description = "List all running servers")
	public boolean list() {
		synchronized(bnet.server_map) {FileSystem.log("bnet server list.\n"+new JSONObject(bnet.server_map).toString(4));}
		
		return true;
	}
	
	@Command(name = "status", description = "Get the status of a server")
	public Integer status(@Parameters(arity = "1", defaultValue = "bnet", description = "Name of the server to get status of.", paramLabel = "name") String name) {
		Object[] arr = findServer(name);
		
		if(arr != null) {
			Object s = arr[0];
		
			if(s != null) {
				int 
				clients 	= (boolean) arr[1]? ((tcpServer) s).client_list.size():  	((webServer) s).client_list.size(),
				rooms 		= (boolean) arr[1]? ((tcpServer) s).room_map.size():  		((webServer) s).room_map.size(),
				namespaces 	= (boolean) arr[1]? ((tcpServer) s).namespace_map.size():  	((webServer) s).namespace_map.size();
				
				FileSystem.log("bnet server status.\nClients 	: "+clients+"\nRooms 		: "+rooms+"\nNamespaces 	: "+namespaces);
				
			}else FileSystem.log("bnet server not found");
		}
		
		return null;
	}
	
	@Command(name = "start", description = "Starts a Tcp-Udp (tcp) or WebServer(ws, wss) for bnet Gms client.", mixinStandardHelpOptions = true)
	public Integer start(
		@Option(names = {"-p", "--protocol"}, defaultValue = "tcp", description = "Protocol to initiate the server as: tcp, ws, wss.", paramLabel = "PROTOCOL")
		String protocol,
		@Option(names = {"-n", "--name"}, defaultValue = "bnet", description = "Name to assign to server.", paramLabel = "NAME")
		String name,
		@Option(names = "-ip", defaultValue = "127.0.0.1", description = "Ip to bind server to.", paramLabel = "IP")
		String ip,
		@Option(names = {"-u", "-up", "--udpPort"}, defaultValue = "30001", description = "Udp port to bind Tcp-Udp Server to.", paramLabel = "UDP")
		int udpPort,
		@Option(names = {"-t", "-tp", "--tcpPort"}, defaultValue = "30001", description = "Tcp port to bind Tcp-Udp Server to.", paramLabel = "TCPPORT")
		int tcpPort,
		@Option(names = {"-w", "-wp", "--webPort"}, defaultValue = "30002", description = "Web-Socket port to bind Server to.", paramLabel = "WEBPORT")
		int webPort,
		@Option(names = {"-mc", "--max_clients"}, defaultValue = "1000", description = "Maximum amount of clients that can join the server.", paramLabel = "MAXCLIENTS")
		int max_clients,
		@Option(names = {"-v", "--ver"}, defaultValue = "1.0.0", description = "Version to assign to server.", paramLabel = "VERSION")
		String version,
		@Option(names = {"-kfp", "--keystoreFilePath"}, defaultValue = "", description = "Key-store file path.", paramLabel = "PATH")
		String keystoreFilePath,
		@Option(names = {"-ksp", "--keystorePassword"}, defaultValue = "", description = "Key-store password.", paramLabel = "PASSWORD")
		String keystorePassword,
		@Option(names = {"-tfp", "--truststoreFilePath"}, defaultValue = "JKS", description = "Trust-store file path.", paramLabel = "PATH")
		String truststoreFilePath,
		@Option(names = {"-tsp", "--truststorePassword"}, defaultValue = "", description = "Trust-store password.", paramLabel = "PASSWORD")
		String truststorePassword,
		@Option(names = {"-f", "--fps"}, defaultValue = "60", description = "Server frames per second", paramLabel = "FPS")
		int fps,
		@Option(names = {"-m", "--mtu"}, defaultValue = "700", description = "Maximum transmit unit for udp packet", paramLabel = "UDP")
		int mtu
	){
		synchronized(bnet.server_map) {
			if(bnet.server_map.get(name) != null) {
				FileSystem.log("bnet server create failed server with name already exists.");
				
				return 0;
			}
		}
		
		HashMap<String, Object> map = new HashMap<>();
		
		boolean binded = false;
		
		switch(protocol) {
			case "tcp": case "t":
				try {
					tcpServer server = new tcpServer(name, ip, tcpPort, udpPort, max_clients, version, fps, mtu);
					
					map = new HashMap<>();
					
					map.put("name", name);
					map.put("protocol",  protocol);
					map.put("ip",  ip);
					map.put("tcpPort",  tcpPort);
					map.put("udpPort",  udpPort);
					map.put("version",  version);
					map.put("max_clients",  max_clients);
					map.put("fps",  fps);
					map.put("mtu",  mtu);
					
					synchronized(bnet.server_map) {bnet.server_map.put(name, map);}
						
					synchronized(bnet.server_list) {bnet.server_list.add(server);}
					
					server.map = map;
					
					bnet.thread_pool.execute(server);
				} catch (Throwable e) {
					FileSystem.log("bnet failed to start server "+e.getMessage());
					
					FileSystem.onError(e);
				}
			break;	
			case "w": case "ws": case "wss":
				synchronized(bnet.server_list) {
					for(int i = 0; i < bnet.server_list.size(); i++) {
						Object s = bnet.server_list.get(i);
						
						if(s.getClass() == tcpServer.class) {
							if(webPort == ((tcpServer) s).tcpPort || webPort == ((tcpServer) s).udpPort) {
								FileSystem.log("bnet failed to start server port already binded.");
								
								binded = true;
								
								break;
							}
						}else {
							if(webPort == ((webServer) s).port) {
								FileSystem.log("bnet failed to start server port already binded.");
								
								binded = true;
								
								break;
							}
						}
					}
				}
				
				if(binded) break;
				try {
					webServer server = new webServer(protocol, name, ip, webPort, max_clients, version, fps, keystoreFilePath, keystorePassword, truststoreFilePath, truststorePassword);
					
					map = new HashMap<>();
					
					map.put("name", name);
					map.put("protocol",  protocol);
					map.put("ip",  ip);
					map.put("webPort",  webPort);
					map.put("version",  version);
					map.put("max_clients",  max_clients);
					map.put("fps",  fps);
					
					synchronized(bnet.server_map) {bnet.server_map.put(name, map);}
						
					synchronized(bnet.server_list) {bnet.server_list.add(server);}
					
					server.map = map;
					
					bnet.thread_pool.execute(server);
				} catch (Throwable e) {
					FileSystem.log("bnet failed to start server "+e.getMessage());
					
					FileSystem.onError(e);
				}
			break;
			default:
				FileSystem.log("bnet failed to start server invalid protocol: { "+protocol+" }.");
			break;
		}
		return 0;
	};
	
	@Command(name = "stop", description = "Terminates a pre-existing server.")
	public Integer stop(
		@Parameters(defaultValue = "bnet", description = "Name of server to terminate.", paramLabel = "Server")
		String name,
		@Parameters(defaultValue = "1", description = "Countdown alarm before shutting down server. In seconds.", paramLabel = "alarm")
		int alarm
		
	) {
		Object server 	= null;
		boolean tcp 	= false;
		
		synchronized(bnet.server_list) {
			for(int i = 0; i < bnet.server_list.size(); i++) {
				
				Object s = bnet.server_list.get(i);
				
				if(s.getClass() == tcpServer.class) {
					if(name.equals(((tcpServer) s).id)){
						server 	= s; 
						tcp 	= true;
						
						break;
					}
				}else {
					if(name.equals(((webServer) s).id)){
						server 	= s; 
						
						break;
					}
				}
			}
		}
		
		if(server != null) {
			if(tcp) ((tcpServer) server).onShutDown(alarm);
			else ((webServer) server).onShutDown(alarm);
		}else FileSystem.log("bnet failed to stop server invalid name");
		
		return 0;
	}
	
	@Override
	public void run() {}
	
	static Object[] findServer(String name){
		synchronized(bnet.server_list) {
			for(int i = 0; i < bnet.server_list.size(); i++) {
				Object s = bnet.server_list.get(i);
				
				if(s.getClass() == tcpServer.class) {
					if(name.equals(((tcpServer) s).id)) return new Object[] {s, true};
				}else if(name.equals(((webServer) s).id)) return new Object[] {s, false};
			}
		}
		return null;
	}
}